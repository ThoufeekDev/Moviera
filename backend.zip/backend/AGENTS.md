# Backend Rules (`backend/`)

Read the root `AGENTS.md` first. This file adds the backend architecture rules.

## Stack and commands

Node.js, TypeScript (strict, CommonJS), Express 5, Prisma 6 + PostgreSQL (Neon), Zod 4, Vitest + Supertest, Cloudinary (images), Redis + BullMQ (jobs), Resend (email), Sentry.

| Task | Command |
|---|---|
| Dev server | `npm run dev` |
| Type check | `npx tsc --noEmit` |
| Tests | `npm run test:run` |
| Validate schema | `npx prisma validate` |
| New migration | `npx prisma migrate dev --name <snake_case_name>` |

There is no lint script yet. Do not add one unless asked.

## Architecture

Modular monolith, clean architecture, light CQRS, SOLID, manual dependency injection.

### Dependency rule (never break)

```
presentation  -->  application  -->  domain
infrastructure -->  application, domain
```

- `domain` imports nothing from `application`, `infrastructure`, `presentation`, Prisma or Express.
- `application` never imports `@prisma/client`, `express`, `infrastructure/*` or `presentation/*`. Depend on interfaces (ports) only. Use domain enums, never Prisma enums.
- `presentation` never imports Prisma or `infrastructure/*`. Controllers know only use cases, schemas, response helpers and `HttpTypes`.
- `infrastructure` is the only place that touches Prisma, Cloudinary, Redis and Resend.
- Modules talk to each other only through `modules/<module>/index.ts`. Never deep-import another module's internals.

### Module template

```
src/modules/<module>/
  index.ts                  public API: buildXModule + exported types only
  <module>.module.ts        composition root (builds repos, services, use cases, controllers, routers)
  domain/
    entities/  types/  repositories/  enums/  constants/  value-objects/
  application/
    commands/               write use cases
    queries/                read use cases
    query-params/           query enums and filter types
    dtos/                   input types for use cases
    read-models/            output shapes for reads (plain interfaces)
    ports/                  interfaces for query services and external services
    services/               application services (slug, validators)
  infrastructure/persistence/
    repositories/  queries/  mappers/  selects/
  presentation/
    controllers/  routes/  schemas/  response-mappers/
```

Cross-module shared code lives in `src/shared/` (http, errors, middleware, utils, types). Wiring lives in `src/main/container.ts` and `src/app.ts`.

## Naming

| Thing | Convention | Example |
|---|---|---|
| Use case | `VerbNounUseCase` in `commands/` (writes) or `queries/` (reads) | `CreateFacilityUseCase` |
| Controller | `VerbNounController` with one `handle` arrow property | `ListFacilitiesController` |
| Zod schema | `VerbNounSchema.ts` exporting `verbNounSchema` and `VerbNounInput` | `createFacilitySchema` |
| Repository | `IXRepository` (domain), `PrismaXRepository` (infrastructure) | `IFacilityRepository` |
| Query service | `IXQueryService` (port), `PrismaXQueryService` | `ITheatreQueryService` |
| Read model | plain interface, no behavior | `SuperAdminFacilityListItem` |
| Files | one class or interface per file, file name = class name | |
| Methods | `camelCase` | `listFacilities` |
| Tests | colocated `*.test.ts` | `CreateFacilityUseCase.test.ts` |

The Prisma model for facilities is `TheatreFacility` (not `Facility`). Check `prisma/schema.prisma` before writing queries.

## Request flow

```
route -> authenticateUser -> authorizeRoles(Role.X) -> [upload] -> validate({ body, params, query }) -> adapt(controller.handle) -> use case -> repository / query service
```

- Controllers are framework-free: `handle(req: HttpRequest<P, B, Q>): Promise<HttpResponse<R>>`, wrapped by `adapt()`.
- Respond with `ok()` or `created()` from `shared/http/response`. Never call `res.json` in a controller.
- Keep the defensive `if (!req.user?.userId) throw new UnauthorizedError(...)` in authenticated controllers.
- Server-owned fields (`createdById`, `id`, `slug`, `deletedAt`, timestamps) are set after spreading `req.body`, never taken from it.

Controller template:

```ts
export class CreateXController {
  constructor(private readonly createXUseCase: CreateXUseCase) {}

  handle = async (
    req: HttpRequest<unknown, CreateXInput, unknown>,
  ): Promise<HttpResponse<XResult>> => {
    if (!req.user?.userId) throw new UnauthorizedError('Authentication required');
    const result = await this.createXUseCase.execute({
      ...req.body,
      createdById: req.user.userId,
    });
    return created(result, 'X created successfully');
  };
}
```

Use case template:

```ts
export class CreateXUseCase implements IUseCase<CreateXDTO, XResult> {
  constructor(private readonly xRepository: IXRepository) {}

  async execute(request: CreateXDTO): Promise<XResult> {
    // 1 normalize  2 duplicate checks  3 build entity  4 persist  5 map to read model
  }
}
```

Route template (static routes first, `/:id` routes last):

```ts
router.post(
  '/x',
  ...superAdmin,
  validate({ body: createXSchema }),
  adapt(controllers.createXController.handle),
);
```

## Reads vs writes (CQRS)

- **Commands** go through repositories and domain entities.
- **Queries** go through `IXQueryService` and return read models straight from Prisma `select`. Never return entities or raw Prisma models from a query.
- Every API response is a DTO or read model. Never expose a Prisma model.

### List endpoint standard (required for every list)

- Zod query schema: `search` (trimmed), `status` (`ALL | ACTIVE | INACTIVE`, default `ALL`), `page` (int >= 1, default 1), `limit` (int 1 to 100, default 20).
- Clamp `page` and `limit` again inside the query service.
- Search uses `contains` with `mode: 'insensitive'`. Multiple fields combine with `OR`. Search and status combine with `AND`.
- Deterministic order, always with an `id` tiebreaker: `orderBy: [{ createdAt: 'desc' }, { id: 'asc' }]`.
- Run `findMany` and `count` with the same `where` inside `Promise.all`, then return `toPaginatedResult(items, total, page, limit)`.
- Counts of relations use Prisma `_count` in the same query. No N+1 queries.
- If the model has `deletedAt`, every read filters `deletedAt: null` (admin "show archived" views are explicit exceptions).

## Validation and normalization

- Validate at the edge with Zod (`validate` middleware). Business rules (uniqueness, existence, ownership) are checked in the use case.
- Normalize in the use case: trim, collapse repeated spaces, lowercase emails, convert empty strings to `null` for optional unique fields (for example `licenseNumber`).
- Slugs are generated on the server (slug service), unique within their scope, and never change after creation.
- Duplicate checks are case-insensitive in the use case. Also keep the unique constraint as the safety net (the global handler maps `P2002` to 409).
- Conflict messages must say what clashed. When the clashing row is soft-deleted, say so.

## Errors

- Throw `AppError` subclasses from `shared/errors` (`NotFoundError`, `ConflictError`, `BadRequestError`, `ForbiddenError`, `UnauthorizedError`, `ValidationError`) from the application and presentation layers.
- Throw `DomainError` only for domain invariant violations.
- `shared/middleware/errrorHandler.ts` is the single place that turns errors into responses. Never build error responses by hand.
- Prefer field-level errors: pass `details: { field: 'licenseNumber' }` so the frontend does not guess from message text. `AppError` already supports `details`. Extend the subclass constructor when you first need it.
- Never swallow errors with an empty `catch {}`. If failure is acceptable (for example best-effort image cleanup), log it.

## Prisma and database

- Ids are `cuid()`. Every model has `createdAt` and `updatedAt`. Index foreign keys and filter columns. Use composite `@@unique` for scoped uniqueness. Set `onDelete` explicitly on relations.
- Migrations: additive and optional first. Never edit an applied migration. Name them in `snake_case`. Report data issues (duplicates that would break a new unique constraint) instead of guessing.
- Neon: the app uses the pooled URL, `prisma migrate` needs the direct (non-pooler) URL (`directUrl`).
- Multi-table writes use `prisma.$transaction` inside a repository method, never in a controller.
- Uploads go through `IStorageService`. Store `publicId` beside the URL. If the DB write fails after an upload, delete the uploaded file.
- Soft delete is `deletedAt`. Do not hard-delete rows that other tables reference. Deactivate with `isActive` instead.

## Auth and security

- Every non-public route has `authenticateUser` and `authorizeRoles(...)`.
- Theatre-scoped actions check ownership through `ITheatreAccessPolicy`, not only the role.
- Image uploads use `shared/middleware/upload.middleware` (5 MB, jpeg/png/webp).
- Never log tokens, OTPs, passwords, captcha tokens or email contents. Rate limit sensitive routes.
- Configuration comes from `config/env.ts`. Never read `process.env` elsewhere.

## Wiring a new piece

1. Build the repository, query service, services, use cases and controllers inside `<module>.module.ts`.
2. Add routes in `presentation/routes/*.routes.ts` through a `createXRoutes(controllers)` factory.
3. Return the router from `buildXModule` and mount it in `src/app.ts` through `src/main/container.ts`.
4. Resource paths are plural kebab-case. Verbs: `GET` read, `POST` create, `PUT` full update, `PATCH` partial or status.
5. Export only what other modules need from `index.ts`.

## Testing (Vitest)

- Every use case has a colocated test with mocked ports. Type the mocks (`vi.fn()`, `Partial<IXRepository>`). Do not use `any`.
- Every Zod schema has a test (valid, invalid, edge, stripped unknown keys).
- Query services: test `where`, pagination clamp, ordering and mapping with a mocked Prisma client.
- Controllers: test auth guard and response shape.
- Cover: happy path, each validation failure, each conflict, each permission failure.
- Supertest integration tests only for critical flows.

## Code style

- Strict TypeScript. No `any` (use `unknown` and narrow). No non-null `!` on external input.
- No `console.*` in committed code. Errors go through the error handler and Sentry. If a logger is needed, create `shared/infrastructure/logging/logger.ts` first and ask before introducing it.
- Comments explain why, not what. No commented-out code.
- Keep files focused. Split a use case or query service that grows past roughly 250 lines.

## New feature checklist (in order)

1. `schema.prisma` change and migration
2. Domain: entity, props type, repository interface, enums
3. Application: DTO, read model, port, use case, service
4. Infrastructure: repository, mapper, query service
5. Presentation: Zod schema, controller, route
6. Wire in `<module>.module.ts`, `container.ts`, `app.ts`
7. Tests for use case, schema, query service, controller
8. Run `npx tsc --noEmit`, `npm run test:run`, `npx prisma validate`
9. Final report (root `AGENTS.md`)

## Known debt (do not copy, fix only when a task asks)

- **Soft delete is never filtered in reads.** `deletedAt` is set but queries in `PrismaTheatreQueryService` do not exclude it. Any new or changed theatre query must filter `deletedAt: null`.
- `application` imports `@prisma/client` in `TheatreWithCity`, `AssignTheatreAdminUseCase`, `UpdateTheatreAdminAssignmentUseCase`. Use domain types and enums.
- `ITheatreQueryService` mixes theatres, cities and facilities. Prefer one query port per read concern when you touch it.
- Pagination clamp code is duplicated and defaults disagree (schema default 20, service default 10).
- `console.log` leftovers (`CreateTheatreUseCase`, `verifyTurnstile` logs the captcha token, `ResendEmailService` logs responses).
- `TheatreFacility` has both `icon` and `iconKey`, and no DB-level unique on `name`.
- Naming drift: `errrorHandler.ts`, `ListAllTheatres` (PascalCase method), enum type named `status`, `ListTheatresForAdmin` vs `ListAllTheatreForAdmin`, duplicate routes `/language` and `/languages`.
- CORS origin is hardcoded to `http://localhost:5173`. `env.ts` validates only `JWT_SECRET`.
- Upload filter trusts the client-sent `mimetype`.
- `coverage/` contains stale `hospital` and `doctor` reports. Do not commit coverage output.
