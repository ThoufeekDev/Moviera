import { ILanguageRepository } from "../../domain/repositories/ILanguageRepository";
import { Language } from "../../domain/entities/Language";

export class ListLanguagesUseCase {
  constructor(private readonly repository: ILanguageRepository) {}

  async execute(): Promise<Language[]> {
    return await this.repository.findAll();
  }
}
