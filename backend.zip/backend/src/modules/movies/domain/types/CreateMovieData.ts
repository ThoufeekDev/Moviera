import { Certification } from "../enums/Certification";

export interface CreateMovieData {
  title: string;
  slug: string;
  description: string | null;
  duration: number;
  releaseDate: Date;
  primaryGenreId: string;
  genreIds: string[];
  posterUrl: string | null;
  posterPublicId: string | null;
  backdropUrl: string | null;
  backdropPublicId: string | null;
  trailerUrl: string | null;
  isActive: boolean;

  languageIds: string[];
  theatreFormatIds: string[];
  certification: Certification;

  cast: {
    personId: string;
    character?: string | null;
  }[];

  crew: {
    personId: string;
    job: string;
  }[];
}
