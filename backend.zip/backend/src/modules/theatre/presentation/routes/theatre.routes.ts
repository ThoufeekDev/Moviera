import { Router } from 'express';
import { authenticateUser } from '../../../../shared/middleware/authenticateUser';
import { authorizeRoles } from '../../../../shared/middleware/authorizeRoles';
import { Role } from '../../../../shared/enums/Role';
import { validate } from '../../../../shared/middleware/validate';
import { adapt } from '../../../../shared/http/expressAdapter';
import { createScreenSchema } from '../schemas/CreateScreenSchema';
import { getTheatreOverviewParamSchema } from '../schemas/TheatreParamsSchema';
import { GetMyTheatresController } from '../controllers/GetMyTheatresController';
import { CreateScreenController } from '../controllers/CreateScreenController';
import { GetTheatreOverviewController } from '../controllers/GetTheatreOverviewController';
import { AssignTheatreAdminController } from '../controllers/AssignTheatreAdminController';
import { assignTheatreAdminSchema } from '../schemas/AssignTheatreAdminSchema';
import { UpdateTheatreAdminAssignmentController } from '../controllers/UpdateTheatreAdminAssignmentController';
import {
  updateTheatreAdminAssignmentBodySchema,
  updateTheatreAdminAssignmentParamSchema,
} from '../schemas/UpdateTheatreAdminAssignmentSchema';
import { RevokeTheatreAdminAssignmentController } from '../controllers/RevokeTheatreAdminAssignmentController';
import { revokeTheatreAdminAssignmentParamSchema } from '../schemas/RevokeTheatreAdminAssignmentSchema';
import { ListTheatresForAdminController } from '../controllers/ListTheatresForAdminController';
import { listTheatresForAdminQuerySchema } from '../schemas/ListTheatresForAdminSchema';
import { ListTheatreAdminAssignmentsController } from '../controllers/ListTheatreAdminAssignmentsController';
import { listTheatreAdminAssignmentsQuerySchema } from '../schemas/ListTheatreAdminAssignmentsSchema';
import { ListEligibleTheatreAdminsController } from '../controllers/ListEligibleTheatreAdminsController';
import { listEligibleAdminsQuerySchema } from '../schemas/ListEligibleAdminsSchema';
import { GetTheatreAdminStatsController } from '../controllers/GetTheatreAdminStatsController';
import { ListAllTheatresController } from '../controllers/ListAllTheatresController';
import { listAllTheatresQuerySchema } from '../schemas/ListAllTheatresSchema';
import { CreateTheatreController } from '../controllers/CreateTheatreController';
import { createTheatreSchema } from '../schemas/CreateTheatreSchema';
import { ListCitiesController } from '../controllers/ListCitiesController';
import { ListFacilitiesController } from '../controllers/ListFacilitiesController';
import { ListActiveFacilitiesController } from '../controllers/ListActiveFacilitiesController';
import { CreateFacilityController } from '../controllers/CreateFacilityController';
import { EditFacilityController } from '../controllers/EditFacilityController';
import { ToggleFacilityStatusController } from '../controllers/ToggleFacilityStatusController';
import { ListScreensController } from '../controllers/ListScreenController';
import { listScreensQuerySchema } from '../schemas/ListScreenSchema';
import { listFacilitiesQuerySchema } from '../schemas/ListFacilitiesSchema';
import { createFacilitySchema } from '../schemas/CreateFacilitySchema';
import {
  editFacilityBodySchema,
  editFacilityParamSchema,
} from '../schemas/EditFacilitySchema';
import {
  toggleFacilityStatusBodySchema,
  toggleFacilityStatusParamSchema,
} from '../schemas/ToggleFacilityStatusSchema';
import { GetSuperAdminTheatreDetailController } from '../controllers/GetSuperAdminTheatreDetailController';
import { upload } from '../../../../shared/middleware/upload.middleware';

interface TheatreRouteControllers {
  getMyTheatresController: GetMyTheatresController;
  createScreenController: CreateScreenController;
  getTheatreOverviewController: GetTheatreOverviewController;
  assignTheatreAdminController: AssignTheatreAdminController;
  updateTheatreAdminAssignmentController: UpdateTheatreAdminAssignmentController;
  revokeTheatreAdminAssignmentController: RevokeTheatreAdminAssignmentController;
  listTheatresForAdminController: ListTheatresForAdminController;
  listTheatreAdminAssignmentsController: ListTheatreAdminAssignmentsController;
  listEligibleTheatreAdminsController: ListEligibleTheatreAdminsController;
  getTheatreAdminStatsController: GetTheatreAdminStatsController;
  listAllTheatresController: ListAllTheatresController;
  createTheatreController: CreateTheatreController;
  listCitiesController: ListCitiesController;
  listFacilitiesController: ListFacilitiesController;
  listActiveFacilitiesController: ListActiveFacilitiesController;
  createFacilityController: CreateFacilityController;
  editFacilityController: EditFacilityController;
  toggleFacilityStatusController: ToggleFacilityStatusController;
  getSuperAdminTheatreDetailController: GetSuperAdminTheatreDetailController;
  listScreensController: ListScreensController;
}

export function createTheatreRoutes(controllers: TheatreRouteControllers): Router {
  const router = Router();
  const theatreAdmin = [authenticateUser, authorizeRoles(Role.THEATRE_ADMIN)];
  const superAdmin = [authenticateUser, authorizeRoles(Role.SUPER_ADMIN)];

  // ── Super Admin Theatre Browsing / Listing Route ──────────────────────────
  router.get(
    '/',
    ...superAdmin,
    validate({ query: listAllTheatresQuerySchema }),
    adapt(controllers.listAllTheatresController.handle),
  );

  // ── Super Admin Create Theatre Route ──────────────────────────────────────
  router.post(
    '/',
    ...superAdmin,
    upload.single('logo'),
    validate({ body: createTheatreSchema }),
    adapt(controllers.createTheatreController.handle),
  );




  // ── Theatre Admin Routes ──────────────────────────────────────────────────
  router.get(
    '/my-theatres',
    ...theatreAdmin,
    adapt(controllers.getMyTheatresController.handle),
  );

  router.get(
  '/:theatreId/screens',
  ...theatreAdmin,
  validate({
    params: getTheatreOverviewParamSchema,
    query: listScreensQuerySchema,
  }),
  adapt(controllers.listScreensController.handle),
);

  router.post(
    '/screens',
    ...theatreAdmin,
    validate({ body: createScreenSchema }),
    adapt(controllers.createScreenController.handle),
  );

  // ── Super Admin Theatre Management Routes ─────────────────────────────────
  // 1. List theatres with screen/seat counts and assigned admins for Super Admin
  router.get(
    '/for-admin',
    ...superAdmin,
    validate({ query: listTheatresForAdminQuerySchema }),
    adapt(controllers.listTheatresForAdminController.handle),
  );

  // 2. High-level dashboard statistics
  router.get(
    '/admin-stats',
    ...superAdmin,
    adapt(controllers.getTheatreAdminStatsController.handle),
  );

  // 3. Eligible users with THEATRE_ADMIN role
  router.get(
    '/eligible-admins',
    ...superAdmin,
    validate({ query: listEligibleAdminsQuerySchema }),
    adapt(controllers.listEligibleTheatreAdminsController.handle),
  );

  // 4. Assignments listing (all or by theatre)
  router.get(
    '/admin-assignments',
    ...superAdmin,
    validate({ query: listTheatreAdminAssignmentsQuerySchema }),
    adapt(controllers.listTheatreAdminAssignmentsController.handle),
  );

  // 5. Assign admin to theatre
  router.post(
    '/admin-assignments',
    ...superAdmin,
    validate({ body: assignTheatreAdminSchema }),
    adapt(controllers.assignTheatreAdminController.handle),
  );

  // 6. Update assignment status (Active/Suspended) or role
  router.patch(
    '/admin-assignments/:assignmentId',
    ...superAdmin,
    validate({
      params: updateTheatreAdminAssignmentParamSchema,
      body: updateTheatreAdminAssignmentBodySchema,
    }),
    adapt(controllers.updateTheatreAdminAssignmentController.handle),
  );

  // 7. Revoke/Unassign admin from theatre
  router.delete(
    '/admin-assignments/:assignmentId',
    ...superAdmin,
    validate({ params: revokeTheatreAdminAssignmentParamSchema }),
    adapt(controllers.revokeTheatreAdminAssignmentController.handle),
  );

  // ── Cities List for Dropdown (Static Route) ───────────────────────────────
  router.get(
    '/cities',
    ...superAdmin,
    adapt(controllers.listCitiesController.handle),
  );

  // ── Super Admin Facilities Management Routes (Static Routes) ──────────────
  // 1. List facilities with pagination, search, status, and assigned theatre count
  router.get(
    '/facilities',
    ...superAdmin,
    validate({ query: listFacilitiesQuerySchema }),
    adapt(controllers.listFacilitiesController.handle),
  );

  // 2. Active-only lightweight list for dropdowns
  router.get(
    '/facilities/active',
    ...superAdmin,
    adapt(controllers.listActiveFacilitiesController.handle),
  );

  // 3. Create facility
  router.post(
    '/facilities',
    ...superAdmin,
    validate({ body: createFacilitySchema }),
    adapt(controllers.createFacilityController.handle),
  );

  // 4. Edit facility
  router.put(
    '/facilities/:facilityId',
    ...superAdmin,
    validate({
      params: editFacilityParamSchema,
      body: editFacilityBodySchema,
    }),
    adapt(controllers.editFacilityController.handle),
  );

  // 5. Activate or deactivate facility
  router.patch(
    '/facilities/:facilityId/status',
    ...superAdmin,
    validate({
      params: toggleFacilityStatusParamSchema,
      body: toggleFacilityStatusBodySchema,
    }),
    adapt(controllers.toggleFacilityStatusController.handle),
  );

  // ── Parameterized Route (keep after static routes) ────────────────────────
  router.get(
    '/:theatreId/details',
    ...superAdmin,
    validate({ params: getTheatreOverviewParamSchema }),
    adapt(controllers.getSuperAdminTheatreDetailController.handle),
  );

  router.get(
    '/:theatreId',
    ...theatreAdmin,
    validate({ params: getTheatreOverviewParamSchema }),
    adapt(controllers.getTheatreOverviewController.handle),
  );

  return router;
}
