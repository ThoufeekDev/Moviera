import { Screen } from "../../domain/entities/Screen";
import type { ITheatreRepository } from "../../domain/repositories/ITheatreRepository";
import type { IScreenRepository } from "../../domain/repositories/IScreenRepository";
import type { ITheatreAccessPolicy } from "../ports/ITheatreAccessPolicy";
import type { CreateScreenDTO } from "../dtos/CreateScreenDTO";
import { generateSlug } from "../../../../shared/utils/generateSlug";
import { ConflictError } from "../../../../shared/errors/ConflictError";
import { NotFoundError } from "../../../../shared/errors/NotFoundError";
import { ForbiddenError } from "../../../../shared/errors/ForbiddenError";

export class CreateScreenUseCase {
  constructor(
    private readonly screenRepository: IScreenRepository,
    private readonly theatreRepository: ITheatreRepository,
    private readonly theatreAccessPolicy:ITheatreAccessPolicy,
  ) {}

  async execute(screen: CreateScreenDTO): Promise<Screen> {
    const theatre = await this.theatreRepository.findById(screen.theatreId);
    if (!theatre) throw new NotFoundError("Theatre not found");

    if (!theatre.isActive) throw new ForbiddenError("Theatre is inActive");

    const allowed = await this.theatreAccessPolicy.canManage(screen.actor, screen.theatreId);
    
    if (!allowed) throw new ForbiddenError('You are not assigned to manage this theatre');

    const existingScreen = await this.screenRepository.findByName(
      screen.theatreId,
      screen.name,
    );

    if (existingScreen)
      throw new ConflictError("Screen with this name already exists in this theatre");

    

    return this.screenRepository.create({
      theatreId: screen.theatreId,
      name: screen.name,
      slug:generateSlug(screen.name)
    });
  }
}
