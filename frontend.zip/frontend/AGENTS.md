# Frontend Rules (`frontend/`)

Read the root `AGENTS.md` first. This file adds the frontend architecture rules.

## Stack and commands

React 19, TypeScript, Vite, Tailwind CSS v4, TanStack Query 5, react-router-dom 7, react-hook-form + Zod 4 (`@hookform/resolvers`), zustand 5 (auth only), axios, lucide-react, react-toastify, framer-motion, `class-variance-authority` + `clsx` + `tailwind-merge`.

| Task | Command |
|---|---|
| Dev server | `npm run dev` |
| Lint | `npm run lint` |
| Type check + build | `npm run build` |

No test runner is installed yet. Tests under `__tests__/` are not type-checked or runnable today. When a task needs frontend tests, report it and add Vitest only if the task allows new dependencies.

## Structure

```
src/
  app/        App.tsx, router/ (AppRoutes, RequireRole, PublicRoute), layouts/
  portals/    one folder per role portal: routes.tsx, config/ (sidebar), thin pages
    public/  theatre-admin/  super-admin/
  features/<feature>/
    api/  hooks/  components/  pages/  schemas/  types/  utils/  services/
    keys.ts   index.ts
  shared/     ui/  lib/  hooks/  types/  constants/  components/
  styles/globals.css
```

### Dependency direction

```
app  -->  portals  -->  features  -->  shared
```

- `shared` never imports from `features` or `portals`.
- A feature never imports from `portals` or from another feature's internals. Use the other feature's `index.ts` only.
- Business pages live in `features/<feature>/pages`. Files in `portals/*/pages` are thin wrappers or compose feature pieces.

### Imports

- Use the `@/` alias across folders. Use relative paths inside one feature.
- `import type` for types (the project uses `verbatimModuleSyntax`).
- A feature `index.ts` exports only what other folders need: pages, public types, public hooks and components. Do not re-export every internal file.

## Data layer (always these four pieces)

1. `types/<name>.types.ts`: response and payload types. Use the shared `ApiResponse<T>`. Add a shared `Paginated<T>` type when you need one instead of redeclaring the pagination shape.
2. `api/<name>.api.ts`: plain async functions using the `api` instance from `@/shared/lib/axios`. They return `response.data.data` and accept an optional `AbortSignal`. Never import `axios` directly in a feature.
3. `keys.ts`: one query key factory per feature (`theatreKeys.all`, `theatreKeys.facilities(params)`).
4. `hooks/useX.ts`: wraps the API call.

```ts
// list query
export const useFacilities = (params: GetFacilitiesParams = {}) =>
  useQuery({
    queryKey: theatreKeys.facilities(params),
    queryFn: ({ signal }) => getFacilities(params, signal),
    placeholderData: keepPreviousData,
  });

// mutation
export const useCreateFacility = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateFacilityPayload) => createFacility(payload),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: [...theatreKeys.all, 'facilities'] }),
  });
};
```

- Components never call API functions directly. They use hooks.
- Server data lives only in TanStack Query. Never copy it into `useState` or zustand.
- Invalidate the narrowest key prefix that is affected.
- Success feedback: `toast.success(...)`. Errors: `getErrorMessage` or `extractFormErrors`.

## Forms

- `react-hook-form` + `zodResolver`. The Zod schema lives in `schemas/<name>.schema.ts` and mirrors the backend rules. Client validation is UX only.
- Pure helpers in `utils/`: `build<X>Payload.ts` (shapes the request: trim, empty string to `undefined`, numbers from strings) and `mapServerErrorToField.ts`. Both have unit tests.
- Form state, effects and handlers live in `hooks/use<X>Form.ts`. The component is a thin shell.
- Split a long form into section components that use `FormProvider` and `useFormContext`. Do not pass `register`, `control` and `errors` down as props.
- Render a field once. Do not duplicate fields per mode or tab. Pass a prop when only a label or placeholder differs.
- Disable submit while pending. Reset the form on close. Show server errors on the right field and as a banner when no field matches.
- Reference: `features/theatres/components/create-theatre/`.

## UI system

- Tailwind v4 utility classes only. Design tokens live in `src/styles/globals.css` (`@theme`): `brand-50..700`, `page`, `surface`, `surface-muted`, `border`, `ink`, `nav-*`, `success-*`, `warning-*`, `danger-600`, `info-600`, `radius-sm|md|lg`, `shadow-card|float`, font Roboto.
- Use token classes (`bg-brand-600`, `text-ink`, `border-border`). No raw hex or arbitrary color values. No CSS modules. No inline `style` except for truly dynamic values.
- Merge classes with `cn()`. Variants use `cva` (see `Button` and `Badge`).
- Build from `@/shared/ui` first: Button, Input, Textarea, Select, Combobox, Modal, Card, Badge, Pagination, SearchBar, StatusFilter, ChipSelect, FormSection, EmptyState, ErrorState, ErrorBoundary, Skeleton, ContentLoader, Loader, InlineLoader, RefreshButton, Sidebar, ImageUpload.
- Never create a second Button, Input, Modal, Select, Pagination or SearchBar. A new primitive goes in `shared/ui/<Name>/` with `<Name>.tsx` and `index.ts`, and is exported from `shared/ui/index.ts`.
- Mobile first. Use `sm`, `md`, `lg` breakpoints. Touch targets are at least 44px. Visual direction is BookMyShow-inspired (red brand, clean cards) with consistent spacing and type sizes.
- Icons come from `lucide-react` only. Facility icons go through the `FacilityIcon` registry in `features/theatres/icons`.

## List page pattern (required for every list)

State in the page: `search`, `status` (default `ALL`), `page` (default 1). Page size 20.

- `SearchBar` for search (Search button and Enter apply immediately, typing is debounced, value is trimmed).
- `StatusFilter` for All / Active / Inactive.
- `Pagination` below the list. Show the total matching count.
- Reset `page` to 1 whenever search or status changes. Keep both when the page changes.
- Pass params to the hook with `placeholderData: keepPreviousData`. Pass `signal` to the API so stale requests are cancelled.
- States: loading (skeletons, keep old results visible while refetching), error (`ErrorState` with retry), empty (nothing exists yet), no results (`EmptyState` with "Clear search and filters").
- Reference: `features/theatres/pages/FacilitiesPage.tsx` and `portals/super-admin/pages/ManageTheatresPage.tsx`.

## Routing and portals

- Routes are declared in `portals/<portal>/routes.tsx` as lazy-loaded pages inside `RequireRole`. Sidebar items live in `portals/<portal>/config/*.config.ts`.
- Paths are kebab-case with one canonical path per page. No alias duplicates.
- Admin portals render inside `AdminLayout`.
- Add the route and the sidebar entry together.

## Auth and state

- zustand is used only for the auth store. Everything else is local state or TanStack Query.
- The persisted `user` and `role` are UI hints only. The server enforces permissions.
- Token refresh is handled by the axios interceptor. Do not add retry or refresh logic elsewhere.

## Components and TypeScript

- Function components. Props interface named `<Component>Props`. Pages and feature components use `export default`.
- Keep files under roughly 250 lines. Split by responsibility (sections, hooks, utils).
- No business logic inside JSX. Extract repeated JSX.
- Accessibility: labels for every input, `aria-*` and roles on custom controls, keyboard operable, visible focus.
- No `any`. Use `unknown` and narrow. `interface` for object shapes, `type` for unions. String unions mirror backend enums. Derive form types from `z.infer`.
- No non-null `!` except `document.getElementById('root')`.
- Read env only through `@/shared/lib/env`. Never put secrets in `VITE_*` variables (they ship in the bundle).

## New feature checklist (in order)

1. `types/`
2. `api/`
3. `keys.ts`
4. `hooks/`
5. `schemas/` and `utils/` (if there is a form)
6. `components/` (using `@/shared/ui`)
7. `pages/`
8. Export what is needed through `index.ts`
9. Route in `portals/<portal>/routes.tsx` and sidebar entry
10. Check loading, error, empty, no-results, responsive, keyboard
11. Run `npm run lint` and `npm run build`
12. Final report (root `AGENTS.md`)

## Known debt (do not copy, fix only when a task asks)

- `extractFormErrors` guesses fields from message text. New code uses `details.field` from the API when available.
- API files declare their own response envelope and shared shapes (`FacilityApiResponse`, pagination). Use the shared types.
- `features/theatres/types/theatre.types.ts` is outdated (no `areaId` or `area`).
- `console.*` (17) and `any` (38) in source. Do not add more.
- Raw hex colors in `shared/ui/Sidebar/Sidebar.tsx`. Use tokens.
- Duplicate or alias files and routes: `components/CreateTheatreModal.tsx` is a re-export of the file in `create-theatre/`, `portals/super-admin/pages/FacilitiesPage.tsx` re-exports the feature page, routes `alltheatres` + `theatres/manage` and `facilities` + `theatres/facilities` point to the same pages.
- Very large files: `TheatreAdminAssignModal.tsx` (640 lines), `googlePlaces.service.ts` (549), `Sidebar.tsx` (493), `TheatreAdminManagementPage.tsx` (476).
- `package.json` lists `pnpm` as a dependency. `.gitignore` has a `.env.env` typo and no `node_modules` or `.env` entry (unless a root `.gitignore` covers it).
- `tsconfig.app.json` excludes `__tests__`, so tests are not type-checked.
