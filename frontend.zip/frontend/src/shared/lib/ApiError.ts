export interface ApiErrorResponse {
    success: false;
    message: string;
    code?: string;
    details?: unknown;
}

export class ApiError extends Error {
    statusCode: number;
    response?: ApiErrorResponse;

    constructor(message: string, statusCode: number, response?: ApiErrorResponse) {
        super(message);

        this.name = "ApiError";
        this.statusCode = statusCode;
        this.response = response;

        Object.setPrototypeOf(this, ApiError.prototype);
    }
}

