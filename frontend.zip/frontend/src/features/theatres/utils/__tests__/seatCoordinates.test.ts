import { describe, it, expect } from 'vitest';
import {
  clampDeltaToWorld,
  computeContentRect,
  cornerBoundsToBox,
  computeCornerBounds,
  computeFitView,
  normalizedToWorld,
  snapToSeatGrid,
  worldToNormalized,
} from '../seatCoordinates';
import {
  BLOCK_ORIGIN,
  SEAT_METRICS,
  WORLD_HEIGHT,
  WORLD_WIDTH,
  ZOOM_LIMITS,
} from '../seatMetrics';

describe('seatCoordinates utility', () => {
  it('uses a fixed world mapping that does not depend on seat count', () => {
    const world = normalizedToWorld(0.5, 0.25);
    expect(world.x).toBe(WORLD_WIDTH * 0.5);
    expect(world.y).toBe(WORLD_HEIGHT * 0.25);

    // One seat pitch is a constant normalized step
    const a = worldToNormalized(BLOCK_ORIGIN.x, BLOCK_ORIGIN.y);
    const b = worldToNormalized(BLOCK_ORIGIN.x + SEAT_METRICS.pitchX, BLOCK_ORIGIN.y + SEAT_METRICS.pitchY);
    expect(b.x - a.x).toBeCloseTo(SEAT_METRICS.pitchX / WORLD_WIDTH, 4);
    expect(b.y - a.y).toBeCloseTo(SEAT_METRICS.pitchY / WORLD_HEIGHT, 4);
  });

  it('reversibly converts normalized coordinates to world and back', () => {
    const testPoints = [
      { x: 0.1, y: 0.2 },
      { x: 0.5, y: 0.5 },
      { x: 0.85, y: 0.92 },
      { x: 0, y: 0 },
      { x: 1, y: 1 },
    ];

    for (const pt of testPoints) {
      const world = normalizedToWorld(pt.x, pt.y);
      const restored = worldToNormalized(world.x, world.y);

      expect(restored.x).toBeCloseTo(pt.x, 3);
      expect(restored.y).toBeCloseTo(pt.y, 3);
    }
  });

  it('clamps out-of-boundary values safely between 0 and 1', () => {
    expect(normalizedToWorld(-0.5, -0.2)).toEqual({ x: 0, y: 0 });
    expect(normalizedToWorld(1.5, 2)).toEqual({ x: WORLD_WIDTH, y: WORLD_HEIGHT });
    expect(worldToNormalized(-200, -100)).toEqual({ x: 0, y: 0 });
    expect(worldToNormalized(99999, 99999)).toEqual({ x: 1, y: 1 });
  });

  it('snaps to the seat pitch grid anchored at the block origin', () => {
    const snapped = snapToSeatGrid(BLOCK_ORIGIN.x + 44, BLOCK_ORIGIN.y + 20);
    expect(snapped.x).toBe(BLOCK_ORIGIN.x + SEAT_METRICS.pitchX);
    expect(snapped.y).toBe(BLOCK_ORIGIN.y + SEAT_METRICS.pitchY);

    const already = snapToSeatGrid(BLOCK_ORIGIN.x, BLOCK_ORIGIN.y);
    expect(already).toEqual({ x: BLOCK_ORIGIN.x, y: BLOCK_ORIGIN.y });
  });

  it('clamps a group move so no seat leaves the world', () => {
    const bounds = computeCornerBounds([
      { x: 100, y: 50 },
      { x: 400, y: 300 },
    ])!;

    expect(bounds).toEqual({ minX: 100, minY: 50, maxX: 400, maxY: 300 });

    const left = clampDeltaToWorld(bounds, -5000, -5000);
    expect(left).toEqual({ dx: -100, dy: -50 });

    const right = clampDeltaToWorld(bounds, 99999, 99999);
    expect(right.dx).toBe(WORLD_WIDTH - SEAT_METRICS.width - 400);
    expect(right.dy).toBe(WORLD_HEIGHT - SEAT_METRICS.height - 300);

    const inside = clampDeltaToWorld(bounds, 10, -10);
    expect(inside).toEqual({ dx: 10, dy: -10 });
  });

  it('returns null corner bounds and content rect for an empty selection', () => {
    expect(computeCornerBounds([])).toBeNull();
    expect(computeContentRect([])).toBeNull();
  });

  it('frames seats with room for labels, headers and the screen', () => {
    const rect = computeContentRect([
      { x: 200, y: 200 },
      { x: 500, y: 400 },
    ])!;

    expect(rect.minX).toBeLessThan(200);
    expect(rect.minY).toBeLessThan(200);
    expect(rect.maxX).toBeGreaterThan(500 + SEAT_METRICS.width);
    expect(rect.maxY).toBeGreaterThan(400 + SEAT_METRICS.height);
  });

  it('builds a box that hugs seat boxes plus padding', () => {
    const box = cornerBoundsToBox({ minX: 100, minY: 50, maxX: 400, maxY: 300 }, 24);
    expect(box).toEqual({
      x: 76,
      y: 26,
      width: 300 + SEAT_METRICS.width + 48,
      height: 250 + SEAT_METRICS.height + 48,
    });
  });

  it('fits a world rectangle into the container by scaling the stage only', () => {
    const rect = { minX: 100, minY: 100, maxX: 1100, maxY: 600 };
    const { zoom, pan } = computeFitView(rect, 500, 400);

    expect(zoom).toBeCloseTo(0.5, 5);
    // Rect center lands on the container center
    expect(pan.x + ((rect.minX + rect.maxX) / 2) * zoom).toBeCloseTo(250, 5);
    expect(pan.y + ((rect.minY + rect.maxY) / 2) * zoom).toBeCloseTo(200, 5);

    const huge = computeFitView({ minX: 0, minY: 0, maxX: 100000, maxY: 100000 }, 500, 400);
    expect(huge.zoom).toBe(ZOOM_LIMITS.min);
  });
});
