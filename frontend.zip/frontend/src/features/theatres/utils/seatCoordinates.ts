import {
  BLOCK_ORIGIN,
  SEAT_METRICS,
  WORLD_HEIGHT,
  WORLD_WIDTH,
  ZOOM_LIMITS,
} from './seatMetrics';

export interface WorldRect {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

export function clamp(val: number, min: number, max: number): number {
  return Math.min(Math.max(val, min), max);
}

/** Normalized [0, 1] -> world pixels using the fixed world size (see seatMetrics.ts). */
export function normalizedToWorld(x: number, y: number): { x: number; y: number } {
  return {
    x: clamp(x, 0, 1) * WORLD_WIDTH,
    y: clamp(y, 0, 1) * WORLD_HEIGHT,
  };
}

/** World pixels -> normalized [0, 1] rounded to 4 decimals (<= 0.15 px of error). */
export function worldToNormalized(worldX: number, worldY: number): { x: number; y: number } {
  return {
    x: Math.round(clamp(worldX / WORLD_WIDTH, 0, 1) * 10000) / 10000,
    y: Math.round(clamp(worldY / WORLD_HEIGHT, 0, 1) * 10000) / 10000,
  };
}

/** Snaps a seat's top-left world position to the seat-pitch grid anchored at BLOCK_ORIGIN. */
export function snapToSeatGrid(worldX: number, worldY: number): { x: number; y: number } {
  return {
    x: BLOCK_ORIGIN.x + Math.round((worldX - BLOCK_ORIGIN.x) / SEAT_METRICS.pitchX) * SEAT_METRICS.pitchX,
    y: BLOCK_ORIGIN.y + Math.round((worldY - BLOCK_ORIGIN.y) / SEAT_METRICS.pitchY) * SEAT_METRICS.pitchY,
  };
}

/**
 * Limits a move delta so a group of seats (given by the bounds of their top-left
 * corners) keeps every seat box fully inside the world.
 */
export function clampDeltaToWorld(
  cornerBounds: WorldRect,
  dx: number,
  dy: number,
): { dx: number; dy: number } {
  return {
    dx: clamp(dx, -cornerBounds.minX, WORLD_WIDTH - SEAT_METRICS.width - cornerBounds.maxX),
    dy: clamp(dy, -cornerBounds.minY, WORLD_HEIGHT - SEAT_METRICS.height - cornerBounds.maxY),
  };
}

/** Bounds of seat top-left corners in world pixels. Returns null for an empty list. */
export function computeCornerBounds(points: Array<{ x: number; y: number }>): WorldRect | null {
  if (points.length === 0) return null;

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const p of points) {
    if (p.x < minX) minX = p.x;
    if (p.x > maxX) maxX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.y > maxY) maxY = p.y;
  }
  return { minX, minY, maxX, maxY };
}

/** Rectangle (x, y, width, height) that hugs seat boxes whose top-left corners are in `corners`. */
export function cornerBoundsToBox(
  corners: WorldRect,
  padding: number,
): { x: number; y: number; width: number; height: number } {
  return {
    x: corners.minX - padding,
    y: corners.minY - padding,
    width: corners.maxX - corners.minX + SEAT_METRICS.width + padding * 2,
    height: corners.maxY - corners.minY + SEAT_METRICS.height + padding * 2,
  };
}

/**
 * World rectangle that frames the whole seating block: the seat boxes plus room for the row
 * label column (left), tier headers (top) and the screen with its caption (bottom).
 */
export function computeContentRect(points: Array<{ x: number; y: number }>): WorldRect | null {
  const corners = computeCornerBounds(points);
  if (!corners) return null;

  return {
    minX: corners.minX - 70,
    minY: corners.minY - 70,
    maxX: corners.maxX + SEAT_METRICS.width + 40,
    maxY: corners.maxY + SEAT_METRICS.height + 110,
  };
}

/**
 * Zoom and pan that fit a world rectangle inside the container.
 * Scales the stage only; seat spacing is untouched.
 */
export function computeFitView(
  rect: WorldRect,
  containerWidth: number,
  containerHeight: number,
  maxFitZoom = 1.5,
): { zoom: number; pan: { x: number; y: number } } {
  const width = Math.max(rect.maxX - rect.minX, 1);
  const height = Math.max(rect.maxY - rect.minY, 1);
  const zoom = clamp(
    Math.min(containerWidth / width, containerHeight / height),
    ZOOM_LIMITS.min,
    maxFitZoom,
  );

  return {
    zoom,
    pan: {
      x: (containerWidth - width * zoom) / 2 - rect.minX * zoom,
      y: (containerHeight - height * zoom) / 2 - rect.minY * zoom,
    },
  };
}
