import type { Seat, SeatType } from '../types/seat.types';
import {
  BLOCK_ORIGIN,
  SEAT_METRICS,
  WORLD_HEIGHT,
  WORLD_WIDTH,
} from './seatMetrics';

// Seat geometry is defined once in SEAT_METRICS (seatMetrics.ts)
export const SEAT_WIDTH = SEAT_METRICS.width;
export const SEAT_HEIGHT = SEAT_METRICS.height;
export const SEAT_PITCH_X = SEAT_METRICS.pitchX; // 30px
export const SEAT_PITCH_Y = SEAT_METRICS.pitchY; // 28px
export const SEAT_GAP_X = SEAT_PITCH_X - SEAT_WIDTH; // 2px horizontal gap
export const SEAT_GAP_Y = SEAT_PITCH_Y - SEAT_HEIGHT; // 4px vertical gap

// Aisles are whole empty seat slots so that every seat stays on the pitch grid
export const AISLE_WIDTH_DEFAULT = SEAT_PITCH_X * 2 + SEAT_GAP_X; // two empty seat slots
export const CROSS_AISLE_HEIGHT_DEFAULT = SEAT_PITCH_Y; // one empty row slot

export interface LayoutSection {
  id: string;
  name: string;
  defaultSeatCount: number;
}

export interface LayoutRowConfig {
  id: string;
  rowLabel: string;
  type: SeatType;
  sectionSeats: Record<string, number>; // sectionId -> count (0 = empty)
  hasHorizontalAisleAfter?: boolean;
}

export type LayoutRow = LayoutRowConfig;

export interface SectionLayoutConfig {
  sections: LayoutSection[];
  rows: LayoutRowConfig[];
  verticalAisleSpacingMultiplier?: number;
  horizontalAisleSpacingMultiplier?: number;
  verticalAisleSpacing?: number;
  horizontalAisleSpacing?: number;
}

export interface CalculatedSeatPosition {
  seatId?: string;
  rowLabel: string;
  seatNumber: number;
  type: SeatType;
  sectionId?: string;
  sectionIndex: number;
  // Pixel positions relative to the top-left of the generated block
  pixelX: number;
  pixelY: number;
  // Normalized [0, 1] positions relative to the block extent (used by the live preview only)
  x: number;
  y: number;
  // Normalized [0, 1] positions in the fixed world mapping (what gets persisted)
  nx: number;
  ny: number;
}

export interface RowMetadata {
  rowLabel: string;
  type: SeatType;
  avgY: number;
  minX: number;
  maxX: number;
  seats: Seat[];
  hasAisleAfter: boolean; // True if next row has an expanded cross-aisle gap
}

export interface TierBlockMetadata {
  type: SeatType;
  displayName: string;
  rows: RowMetadata[];
  topY: number;
  bottomY: number;
  // Prop placeholder for price if wired in the future
  priceLabel?: string;
}

export interface PreviewLayoutData {
  seats: CalculatedSeatPosition[];
  totalSeats: number;
  rowCount: number;
  sections: { id: string; name: string; totalSeats: number }[];
  maxSeatsInAnyRow: number;
}

export function buildPreviewData(config: SectionLayoutConfig): PreviewLayoutData {
  const seats = computeSectionLayoutPositions(config);
  const totalSeats = seats.length;

  const sectionTotals: Record<string, number> = {};
  config.sections.forEach((s) => {
    sectionTotals[s.id] = 0;
  });

  for (const s of seats) {
    if (s.sectionId) {
      sectionTotals[s.sectionId] = (sectionTotals[s.sectionId] || 0) + 1;
    }
  }

  const sections = config.sections.map((s) => ({
    id: s.id,
    name: s.name,
    totalSeats: sectionTotals[s.id] || 0,
  }));

  const maxSeatsInAnyRow = config.rows.reduce(
    (max, r) => Math.max(max, computeRowTotalSeats(r, config.sections)),
    0,
  );

  return {
    seats,
    totalSeats,
    rowCount: config.rows.length,
    sections,
    maxSeatsInAnyRow,
  };
}

export interface LayoutMetadata {
  rows: RowMetadata[];
  tierBlocks: TierBlockMetadata[];
  crossAisles: { afterRowLabel: string; y: number }[];
  bounding: {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
    width: number;
    height: number;
  };
  totalSeats: number;
}

/**
 * Calculates total seats for a row across all its sections.
 */
export function computeRowTotalSeats(row: LayoutRowConfig, sections: LayoutSection[]): number {
  return sections.reduce((sum, sec) => {
    const count = Number(row.sectionSeats[sec.id]);
    return sum + (isNaN(count) || count < 0 ? 0 : count);
  }, 0);
}

/**
 * Generates tightly-pitched BookMyShow seating coordinates for the blueprint builder.
 * Seat size: 28x24px, 4px X gap (32px pitch), 6px Y gap (30px pitch).
 */
export function computeSectionLayoutPositions(config: SectionLayoutConfig): CalculatedSeatPosition[] {
  const {
    sections,
    rows,
    verticalAisleSpacingMultiplier = 1.0,
    horizontalAisleSpacingMultiplier = 1.0,
  } = config;

  if (rows.length === 0 || sections.length === 0) {
    return [];
  }

  // Aisles are whole numbers of empty seat slots so every seat stays on the pitch grid
  const verticalAisleSlots = Math.max(1, Math.round(2 * verticalAisleSpacingMultiplier));
  const verticalAisleWidth = verticalAisleSlots * SEAT_PITCH_X + SEAT_GAP_X;
  const crossAisleHeight =
    Math.max(0, Math.round(horizontalAisleSpacingMultiplier)) * CROSS_AISLE_HEIGHT_DEFAULT;

  // 1. Determine max seat count per section across all rows to establish section widths
  const sectionMaxSeats: Record<string, number> = {};
  for (const sec of sections) {
    let max = 0;
    for (const row of rows) {
      const count = Number(row.sectionSeats[sec.id]) || 0;
      if (count > max) max = count;
    }
    sectionMaxSeats[sec.id] = Math.max(max, 1);
  }

  // 2. Compute starting pixel X offset for each section
  const sectionXOffsets: Record<string, number> = {};
  let currentX = 0;
  sections.forEach((sec, idx) => {
    sectionXOffsets[sec.id] = currentX;
    const secWidth = sectionMaxSeats[sec.id] * SEAT_PITCH_X - SEAT_GAP_X;
    currentX += secWidth;
    if (idx < sections.length - 1) {
      currentX += verticalAisleWidth;
    }
  });

  const totalPixelWidth = Math.max(currentX, SEAT_WIDTH);

  // 3. Compute starting pixel Y offset for each row (including cross-aisles and tier gaps)
  const rowYOffsets: number[] = [];
  let currentY = 0;
  rows.forEach((row, rowIndex) => {
    rowYOffsets[rowIndex] = currentY;

    // Normal row progression
    currentY += SEAT_PITCH_Y;

    // Additional cross-aisle gap if specified
    if (row.hasHorizontalAisleAfter && rowIndex < rows.length - 1) {
      currentY += crossAisleHeight;
    }
  });

  const totalPixelHeight = Math.max(currentY - SEAT_GAP_Y, SEAT_HEIGHT);

  // 4. Position seats and compute normalized floats [0, 1]
  const positions: CalculatedSeatPosition[] = [];

  rows.forEach((row, rowIndex) => {
    const pixelY = rowYOffsets[rowIndex];
    const normalizedY = totalPixelHeight > 0 ? Math.round((pixelY / totalPixelHeight) * 10000) / 10000 : 0;

    let seatNumberCounter = 1;

    sections.forEach((sec, secIdx) => {
      const seatCount = Number(row.sectionSeats[sec.id]) || 0;
      if (seatCount <= 0) return;

      const secStartX = sectionXOffsets[sec.id];

      for (let s = 0; s < seatCount; s++) {
        const pixelX = secStartX + s * SEAT_PITCH_X;
        const normalizedX = totalPixelWidth > 0 ? Math.round((pixelX / totalPixelWidth) * 10000) / 10000 : 0;

        positions.push({
          rowLabel: row.rowLabel.trim().toUpperCase(),
          seatNumber: seatNumberCounter,
          type: row.type,
          sectionId: sec.id,
          sectionIndex: secIdx,
          pixelX,
          pixelY,
          x: Math.min(Math.max(normalizedX, 0), 1),
          y: Math.min(Math.max(normalizedY, 0), 1),
          nx: Math.round(((BLOCK_ORIGIN.x + pixelX) / WORLD_WIDTH) * 10000) / 10000,
          ny: Math.round(((BLOCK_ORIGIN.y + pixelY) / WORLD_HEIGHT) * 10000) / 10000,
        });

        seatNumberCounter++;
      }
    });
  });

  return positions;
}

/**
 * Reconstructs rich layout metadata (rows, sections, cross-aisles, tier blocks)
 * purely from saved seat coordinates and labels. All returned positions are world pixels.
 *
 * Rule: Always groups rows by backend `rowLabel`, NEVER by comparing Y values.
 */
export function computeLayoutMetadata(seats: Seat[]): LayoutMetadata {
  if (seats.length === 0) {
    return {
      rows: [],
      tierBlocks: [],
      crossAisles: [],
      bounding: { minX: 0, maxX: 0, minY: 0, maxY: 0, width: 0, height: 0 },
      totalSeats: 0,
    };
  }

  // 1. Group strictly by `rowLabel`
  const rowMap = new Map<string, Seat[]>();
  for (const s of seats) {
    const label = s.rowLabel.trim().toUpperCase();
    const list = rowMap.get(label) || [];
    list.push(s);
    rowMap.set(label, list);
  }

  // 2. Build sorted rows by average Y position
  const rawRows: {
    rowLabel: string;
    type: SeatType;
    avgY: number;
    minX: number;
    maxX: number;
    seats: Seat[];
  }[] = [];

  for (const [rowLabel, rowSeats] of rowMap.entries()) {
    // Sort seats in row from left to right by x
    rowSeats.sort((a, b) => a.x - b.x);

    const avgY = (rowSeats.reduce((sum, s) => sum + s.y, 0) / rowSeats.length) * WORLD_HEIGHT;
    const minX = Math.min(...rowSeats.map((s) => s.x)) * WORLD_WIDTH;
    const maxX = (Math.max(...rowSeats.map((s) => s.x)) * WORLD_WIDTH) + SEAT_WIDTH;
    const type = rowSeats[0]?.type || 'REGULAR';

    rawRows.push({
      rowLabel,
      type,
      avgY,
      minX,
      maxX,
      seats: rowSeats,
    });
  }

  // Sort rows vertically top-to-bottom
  rawRows.sort((a, b) => a.avgY - b.avgY);

  // 3. Detect normal row pitch and identify true cross-aisles
  // Calculate average delta between consecutive rows
  const deltas: number[] = [];
  for (let i = 0; i < rawRows.length - 1; i++) {
    const diff = rawRows[i + 1].avgY - rawRows[i].avgY;
    if (diff > 0) deltas.push(diff);
  }

  // Median or minimum delta represents the standard row pitch
  deltas.sort((a, b) => a - b);
  const normalRowPitch = deltas.length > 0 ? deltas[0] : SEAT_PITCH_Y;
  // A cross-aisle is only marked when gap is significantly larger than standard row pitch (~1.35x)
  const crossAisleThreshold = normalRowPitch * 1.35;

  const rows: RowMetadata[] = [];
  const crossAisles: { afterRowLabel: string; y: number }[] = [];

  for (let i = 0; i < rawRows.length; i++) {
    const r = rawRows[i];
    let hasAisleAfter = false;

    if (i < rawRows.length - 1) {
      const nextR = rawRows[i + 1];
      const gap = nextR.avgY - r.avgY;

      if (gap > crossAisleThreshold) {
        hasAisleAfter = true;
        crossAisles.push({
          afterRowLabel: r.rowLabel,
          y: (r.avgY + nextR.avgY) / 2,
        });
      }
    }

    rows.push({
      ...r,
      hasAisleAfter,
    });
  }

  // 4. Group consecutive rows of identical tier into Tier Blocks
  const tierBlocks: TierBlockMetadata[] = [];
  let currentBlockRows: RowMetadata[] = [];
  let currentType: SeatType | null = null;

  const commitBlock = () => {
    if (currentBlockRows.length > 0 && currentType) {
      const topY = Math.min(...currentBlockRows.map((r) => r.avgY));
      const bottomY = Math.max(...currentBlockRows.map((r) => r.avgY)) + SEAT_HEIGHT;
      tierBlocks.push({
        type: currentType,
        displayName: currentType,
        rows: currentBlockRows,
        topY,
        bottomY,
      });
      currentBlockRows = [];
    }
  };

  for (const r of rows) {
    if (currentType === null) {
      currentType = r.type;
      currentBlockRows.push(r);
    } else if (r.type === currentType) {
      currentBlockRows.push(r);
    } else {
      commitBlock();
      currentType = r.type;
      currentBlockRows.push(r);
    }
  }
  commitBlock();

  // 5. Compute tight bounding box across all seats
  let minSeatX = Infinity;
  let maxSeatX = -Infinity;
  let minSeatY = Infinity;
  let maxSeatY = -Infinity;

  for (const r of rows) {
    if (r.minX < minSeatX) minSeatX = r.minX;
    if (r.maxX > maxSeatX) maxSeatX = r.maxX;
    if (r.avgY < minSeatY) minSeatY = r.avgY;
    if (r.avgY + SEAT_HEIGHT > maxSeatY) maxSeatY = r.avgY + SEAT_HEIGHT;
  }

  return {
    rows,
    tierBlocks,
    crossAisles,
    bounding: {
      minX: minSeatX,
      maxX: maxSeatX,
      minY: minSeatY,
      maxY: maxSeatY,
      width: Math.max(maxSeatX - minSeatX, SEAT_WIDTH),
      height: Math.max(maxSeatY - minSeatY, SEAT_HEIGHT),
    },
    totalSeats: seats.length,
  };
}

/**
 * Correlates newly created backend seats with the computed section layout positions.
 */
export function mapCreatedSeatsToLayoutCoordinates(
  createdSeats: Seat[],
  config: SectionLayoutConfig,
): { seatId: string; x: number; y: number; rotation: number }[] {
  const calculatedPositions = computeSectionLayoutPositions(config);

  const positionMap = new Map<string, { x: number; y: number }>();
  for (const pos of calculatedPositions) {
    const key = `${pos.rowLabel.toUpperCase()}__${pos.seatNumber}`;
    positionMap.set(key, { x: pos.nx, y: pos.ny });
  }

  return createdSeats.map((seat) => {
    const key = `${seat.rowLabel.toUpperCase()}__${seat.seatNumber}`;
    const calculatedPos = positionMap.get(key);

    if (calculatedPos) {
      return {
        seatId: seat.id,
        x: calculatedPos.x,
        y: calculatedPos.y,
        rotation: seat.rotation || 0,
      };
    }

    return {
      seatId: seat.id,
      x: seat.x,
      y: seat.y,
      rotation: seat.rotation || 0,
    };
  });
}

function median(values: number[]): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

/**
 * Rebuilds a tight layout (SEAT_METRICS pitch) from rowLabel and seat order.
 *
 * - Rows are grouped by rowLabel, ordered top to bottom by their current average Y, and
 *   every seat of a row is placed on the same Y.
 * - Seats keep their seatNumber order inside the row.
 * - The "normal" pitch of the existing layout (median spacing) is inferred. A gap is kept
 *   ONLY when it exceeds that normal pitch, and it is kept as a whole number of seat slots
 *   (or row slots), so the result sits exactly on the snap grid.
 * - Irregular row starts are kept as whole-slot indents from the left-most seat.
 */
export function repackSeatsLayout(
  seats: Seat[],
): { id: string; seatId: string; x: number; y: number; rotation: number }[] {
  if (seats.length === 0) return [];

  const rowMap = new Map<string, Seat[]>();
  for (const s of seats) {
    const label = s.rowLabel.trim().toUpperCase();
    const list = rowMap.get(label) || [];
    list.push(s);
    rowMap.set(label, list);
  }

  const toWorld = (seat: Seat) => ({ x: seat.x * WORLD_WIDTH, y: seat.y * WORLD_HEIGHT });

  const rows = Array.from(rowMap.values()).map((rowSeats) => {
    const ordered = [...rowSeats].sort((a, b) => a.seatNumber - b.seatNumber);
    const avgY = ordered.reduce((sum, s) => sum + toWorld(s).y, 0) / ordered.length;
    return { seats: ordered, avgY, firstX: toWorld(ordered[0]).x };
  });
  rows.sort((a, b) => a.avgY - b.avgY);

  // Infer the existing "normal" pitch (median of positive deltas, ignoring overlaps)
  const rowDeltas: number[] = [];
  for (let i = 0; i < rows.length - 1; i++) {
    const diff = rows[i + 1].avgY - rows[i].avgY;
    if (diff > 1) rowDeltas.push(diff);
  }
  const seatDeltas: number[] = [];
  for (const row of rows) {
    for (let i = 0; i < row.seats.length - 1; i++) {
      const diff = toWorld(row.seats[i + 1]).x - toWorld(row.seats[i]).x;
      if (diff > 1) seatDeltas.push(diff);
    }
  }
  const normalRowDelta = median(rowDeltas) ?? SEAT_PITCH_Y;
  const normalSeatDelta = median(seatDeltas) ?? SEAT_PITCH_X;

  const globalMinX = Math.min(...rows.map((r) => Math.min(...r.seats.map((s) => toWorld(s).x))));

  const result: { id: string; seatId: string; x: number; y: number; rotation: number }[] = [];
  let rowSlot = 0;

  rows.forEach((row, rowIndex) => {
    if (rowIndex > 0) {
      const diff = row.avgY - rows[rowIndex - 1].avgY;
      rowSlot += Math.max(1, Math.round(diff / normalRowDelta));
    }

    let seatSlot = Math.max(0, Math.round((row.firstX - globalMinX) / normalSeatDelta));

    row.seats.forEach((seat, seatIndex) => {
      if (seatIndex > 0) {
        const diff = toWorld(seat).x - toWorld(row.seats[seatIndex - 1]).x;
        seatSlot += Math.max(1, Math.round(diff / normalSeatDelta));
      }

      const worldX = BLOCK_ORIGIN.x + seatSlot * SEAT_PITCH_X;
      const worldY = BLOCK_ORIGIN.y + rowSlot * SEAT_PITCH_Y;
      result.push({
        id: seat.id,
        seatId: seat.id,
        x: Math.round(Math.min(worldX / WORLD_WIDTH, 1) * 10000) / 10000,
        y: Math.round(Math.min(worldY / WORLD_HEIGHT, 1) * 10000) / 10000,
        rotation: seat.rotation || 0,
      });
    });
  });

  return result;
}
