import React, { useEffect, useMemo, useRef } from 'react';
import { Stage, Layer, Rect, Text, Line, Group } from 'react-konva';
import type Konva from 'konva';
import { SeatShape } from './SeatShape';
import {
  computeContentRect,
  computeCornerBounds,
  computeFitView,
  cornerBoundsToBox,
  normalizedToWorld,
} from '../../utils/seatCoordinates';
import { computeLayoutMetadata } from '../../utils/sectionLayoutGenerator';
import { BLOCK_ORIGIN, SEAT_METRICS, WORLD_HEIGHT, WORLD_WIDTH } from '../../utils/seatMetrics';
import { SELECTION_THEME } from '../../utils/seatTheme';
import { useSeatEditorStore } from '../../stores/useSeatEditorStore';
import {
  LAYOUT_BOX_PADDING,
  useSeatCanvasInteractions,
} from '../../hooks/useSeatCanvasInteractions';

export interface SeatCanvasProps {
  containerWidth: number;
  containerHeight: number;
  /** Snap seats to the seat pitch grid while dragging (hold Alt to bypass temporarily). */
  snapToGrid?: boolean;
  /** Explicit Hand tool: dragging pans the stage instead of selecting. */
  handToolActive?: boolean;
}

export const SeatCanvas: React.FC<SeatCanvasProps> = ({
  containerWidth,
  containerHeight,
  snapToGrid = true,
  handToolActive = false,
}) => {
  const stageRef = useRef<Konva.Stage>(null);
  const selectionBoxRef = useRef<Konva.Rect>(null);
  const boundsBoxRef = useRef<Konva.Rect>(null);
  const marqueeRef = useRef<Konva.Rect>(null);
  const fittedForScreenRef = useRef<string | null>(null);

  const screenId = useSeatEditorStore((s) => s.screenId);
  const seats = useSeatEditorStore((s) => s.seats);
  const selectedSeatIds = useSeatEditorStore((s) => s.selectedSeatIds);
  const zoom = useSeatEditorStore((s) => s.zoom);
  const pan = useSeatEditorStore((s) => s.pan);
  const selectRow = useSeatEditorStore((s) => s.selectRow);
  const setZoom = useSeatEditorStore((s) => s.setZoom);
  const setPan = useSeatEditorStore((s) => s.setPan);

  const {
    registerNode,
    handleSeatMouseDown,
    handleStageMouseDown,
    handleStageMouseMove,
    handleStageMouseLeave,
    handleWheel,
  } = useSeatCanvasInteractions({
    stageRef,
    selectionBoxRef,
    boundsBoxRef,
    marqueeRef,
    snapToGrid,
    handToolActive,
  });

  // World positions come from the fixed normalized <-> world mapping (see seatMetrics.ts)
  const seatPositions = useMemo(
    () => seats.map((seat) => ({ seat, pos: normalizedToWorld(seat.x, seat.y) })),
    [seats],
  );

  // Row grouping, tier blocks and cross-aisles (grouped strictly by rowLabel)
  const layoutMeta = useMemo(() => computeLayoutMetadata(seats), [seats]);

  // Fit-to-view once per screen. This scales the stage; seat spacing is untouched.
  useEffect(() => {
    if (!screenId || seatPositions.length === 0 || fittedForScreenRef.current === screenId) return;
    fittedForScreenRef.current = screenId;

    const rect = computeContentRect(seatPositions.map((p) => p.pos));
    if (!rect) return;
    const fit = computeFitView(rect, containerWidth, containerHeight);
    setZoom(fit.zoom);
    setPan(fit.pan);
  }, [screenId, seatPositions, containerWidth, containerHeight, setZoom, setPan]);

  // Layout box hugging the seats (+24px). Also updated live, imperatively, while dragging.
  const layoutBox = useMemo(() => {
    const corners = computeCornerBounds(seatPositions.map((p) => p.pos));
    if (!corners) {
      return {
        x: BLOCK_ORIGIN.x - LAYOUT_BOX_PADDING,
        y: BLOCK_ORIGIN.y - LAYOUT_BOX_PADDING,
        width: 400,
        height: 300,
        rawMinX: BLOCK_ORIGIN.x,
        rawMaxX: BLOCK_ORIGIN.x + 400,
        rawMaxY: BLOCK_ORIGIN.y + 300,
      };
    }
    return {
      ...cornerBoundsToBox(corners, LAYOUT_BOX_PADDING),
      rawMinX: corners.minX,
      rawMaxX: corners.maxX + SEAT_METRICS.width,
      rawMaxY: corners.maxY + SEAT_METRICS.height,
    };
  }, [seatPositions]);

  // Active selection box (neutral, 6px padding). Also updated live while dragging.
  const selectionBox = useMemo(() => {
    const corners = computeCornerBounds(
      seatPositions.filter((p) => selectedSeatIds.has(p.seat.id)).map((p) => p.pos),
    );
    return corners ? cornerBoundsToBox(corners, SELECTION_THEME.selectionBox.padding) : null;
  }, [seatPositions, selectedSeatIds]);

  // Wide 3D screen under the seat block (~55% of layout width, 24px below the last row)
  const screen = useMemo(() => {
    const top = layoutBox.rawMaxY + 24;
    const centerX = layoutBox.rawMinX + (layoutBox.rawMaxX - layoutBox.rawMinX) / 2;
    const topWidth = Math.max((layoutBox.rawMaxX - layoutBox.rawMinX) * 0.55, 340);
    const bottomWidth = topWidth * 0.88;
    const height = 16;

    return {
      centerX,
      top,
      topWidth,
      height,
      points: [
        centerX - topWidth / 2,
        top,
        centerX + topWidth / 2,
        top,
        centerX + bottomWidth / 2,
        top + height,
        centerX - bottomWidth / 2,
        top + height,
      ],
    };
  }, [layoutBox]);

  const rowPillX = layoutBox.rawMinX - 34;

  return (
    <div className="relative w-full h-full overflow-hidden select-none bg-white rounded-xl border border-border shadow-xs">
      <Stage
        ref={stageRef}
        width={containerWidth}
        height={containerHeight}
        scaleX={zoom}
        scaleY={zoom}
        x={pan.x}
        y={pan.y}
        onWheel={handleWheel}
        onMouseDown={handleStageMouseDown}
        onMouseMove={handleStageMouseMove}
        onMouseLeave={handleStageMouseLeave}
      >
        {/* Layer 1: background, tier headers, layout box, row labels, screen */}
        <Layer>
          <Rect
            name="background"
            x={0}
            y={0}
            width={WORLD_WIDTH}
            height={WORLD_HEIGHT}
            fill="#FFFFFF"
          />

          {layoutMeta.tierBlocks.map((tier) => {
            const headerY = tier.topY - 18;
            return (
              <Group key={`tier-${tier.displayName}-${tier.topY}`} listening={false}>
                <Text
                  x={layoutBox.x}
                  y={headerY}
                  text={tier.priceLabel ? `${tier.priceLabel} ${tier.displayName}` : tier.displayName}
                  fontSize={10.5}
                  fontStyle="bold"
                  fontFamily="system-ui, -apple-system, sans-serif"
                  fill="#64748B"
                  letterSpacing={1.2}
                />
                <Line
                  points={[layoutBox.x + 80, headerY + 6, layoutBox.x + layoutBox.width, headerY + 6]}
                  stroke="#E2E8F0"
                  strokeWidth={1}
                />
              </Group>
            );
          })}

          <Rect
            ref={boundsBoxRef}
            x={layoutBox.x}
            y={layoutBox.y}
            width={layoutBox.width}
            height={layoutBox.height}
            stroke="#CBD5E1"
            strokeWidth={1.2}
            dash={[5, 5]}
            cornerRadius={8}
            fill="#F8FAFC"
            fillOpacity={0.25}
            listening={false}
          />

          {layoutMeta.rows.map((row) => {
            const pillY = row.avgY + (SEAT_METRICS.height - 22) / 2;
            return (
              <Group
                key={`row-pill-${row.rowLabel}`}
                x={rowPillX}
                y={pillY}
                onClick={() => selectRow(row.rowLabel)}
                onTap={() => selectRow(row.rowLabel)}
              >
                <Rect width={26} height={22} cornerRadius={4} fill="#F1F5F9" stroke="#E2E8F0" strokeWidth={1} />
                <Text
                  text={row.rowLabel}
                  width={26}
                  height={22}
                  align="center"
                  verticalAlign="middle"
                  fontSize={10.5}
                  fontStyle="bold"
                  fontFamily="system-ui, -apple-system, sans-serif"
                  fill="#475569"
                  listening={false}
                />
              </Group>
            );
          })}

          {/* "-" marker only where a real cross-aisle gap exists between two rows */}
          {layoutMeta.crossAisles.map((aisle) => (
            <Text
              key={`cross-aisle-${aisle.afterRowLabel}`}
              x={rowPillX}
              y={aisle.y + SEAT_METRICS.height / 2 - 7}
              width={26}
              text="-"
              align="center"
              fontSize={14}
              fontStyle="bold"
              fill="#94A3B8"
              listening={false}
            />
          ))}

          <Group listening={false}>
            <Line
              points={screen.points}
              closed={true}
              fill="#E0F2FE"
              stroke="#38BDF8"
              strokeWidth={1.5}
              lineJoin="round"
            />
            <Line
              points={[
                screen.centerX - screen.topWidth / 2 + 16,
                screen.top + 3,
                screen.centerX + screen.topWidth / 2 - 16,
                screen.top + 3,
              ]}
              stroke="#BAE6FD"
              strokeWidth={1.2}
              lineCap="round"
            />
            <Text
              x={screen.centerX - 160}
              y={screen.top + screen.height + 12}
              width={320}
              text="All eyes this way please"
              align="center"
              fontSize={10.5}
              fontStyle="bold"
              fontFamily="system-ui, -apple-system, sans-serif"
              fill="#94A3B8"
            />
          </Group>
        </Layer>

        {/* Layer 2: selection box, seats, marquee */}
        <Layer>
          <Rect
            ref={selectionBoxRef}
            visible={selectionBox !== null}
            x={selectionBox?.x ?? 0}
            y={selectionBox?.y ?? 0}
            width={selectionBox?.width ?? 0}
            height={selectionBox?.height ?? 0}
            fill={SELECTION_THEME.selectionBox.fill}
            stroke={SELECTION_THEME.selectionBox.stroke}
            strokeWidth={SELECTION_THEME.selectionBox.strokeWidth}
            dash={[...SELECTION_THEME.selectionBox.dash]}
            cornerRadius={6}
            listening={false}
          />

          {seatPositions.map(({ seat, pos }) => (
            <SeatShape
              key={seat.id}
              seat={seat}
              x={pos.x}
              y={pos.y}
              isSelected={selectedSeatIds.has(seat.id)}
              onSeatMouseDown={handleSeatMouseDown}
              registerNode={registerNode}
            />
          ))}

          <Rect
            ref={marqueeRef}
            visible={false}
            fill={SELECTION_THEME.marquee.fill}
            stroke={SELECTION_THEME.marquee.stroke}
            strokeWidth={SELECTION_THEME.marquee.strokeWidth}
            dash={[...SELECTION_THEME.marquee.dash]}
            listening={false}
          />
        </Layer>
      </Stage>
    </div>
  );
};

