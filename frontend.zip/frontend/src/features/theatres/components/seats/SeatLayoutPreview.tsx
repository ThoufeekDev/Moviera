import React from 'react';
import type { PreviewLayoutData } from '../../utils/sectionLayoutGenerator';
import { SEAT_TYPE_LABELS, type SeatType } from '../../types/seat.types';

export interface SeatLayoutPreviewProps {
  previewData: PreviewLayoutData;
  screenName?: string;
  hasHorizontalAisles?: boolean;
}

const TIER_COLORS: Record<SeatType, { border: string; text: string; bg: string }> = {
  REGULAR: { border: '#1EA83C', text: '#1EA83C', bg: '#FFFFFF' },
  PREMIUM: { border: '#2563EB', text: '#2563EB', bg: '#FFFFFF' },
  RECLINER: { border: '#D97706', text: '#D97706', bg: '#FFFFFF' },
  SOFA: { border: '#7C3AED', text: '#7C3AED', bg: '#FFFFFF' },
  WHEELCHAIR: { border: '#0D9488', text: '#0D9488', bg: '#FFFFFF' },
};

export const SeatLayoutPreview: React.FC<SeatLayoutPreviewProps> = ({
  previewData,
  screenName,
}) => {
  const { seats, totalSeats, sections, rowCount } = previewData;

  // Group seats by row
  const rowsMap = new Map<string, typeof seats>();
  for (const seat of seats) {
    const list = rowsMap.get(seat.rowLabel) || [];
    list.push(seat);
    rowsMap.set(seat.rowLabel, list);
  }

  const rowsList = Array.from(rowsMap.entries());

  if (seats.length === 0) {
    return (
      <div className="flex h-64 flex-col items-center justify-center rounded-xl border border-dashed border-border bg-surface-muted/30 p-6 text-center">
        <p className="text-sm font-medium text-ink-muted">No seats configured yet.</p>
        <p className="mt-1 text-xs text-ink-muted/80">
          Add rows and sections in the configuration table to see a real-time layout preview.
        </p>
      </div>
    );
  }

  // Calculate layout bounds for SVG viewBox
  // Let seat size = 26px, padding = 4px
  const SEAT_BOX_W = 28;
  const SEAT_BOX_H = 24;
  const MARGIN_LEFT = 48;
  const MARGIN_RIGHT = 48;
  const MARGIN_TOP = 40;
  const MARGIN_BOTTOM = 90;

  // Find max grid bounds
  const VIEW_WIDTH = 840;
  const VIEW_HEIGHT = Math.max(340, rowCount * 36 + MARGIN_TOP + MARGIN_BOTTOM);

  const seatingWidth = VIEW_WIDTH - MARGIN_LEFT - MARGIN_RIGHT;
  const seatingHeight = VIEW_HEIGHT - MARGIN_TOP - MARGIN_BOTTOM;

  return (
    <div className="flex flex-col rounded-xl border border-border bg-white shadow-card overflow-hidden">
      {/* Preview Header */}
      <div className="flex flex-wrap items-center justify-between border-b border-border bg-surface-muted/40 px-5 py-3 gap-2">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-ink">
            Live Auditorium Blueprint Preview
          </h4>
          {screenName && (
            <span className="text-xs text-ink-muted">({screenName})</span>
          )}
        </div>

        {/* Section summaries */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          {sections.map((sec) => (
            <div key={sec.id} className="flex items-center gap-1.5 text-ink-muted">
              <span className="font-semibold text-ink">{sec.name}:</span>
              <span className="font-medium text-brand-600">{sec.totalSeats} seats</span>
            </div>
          ))}
          <div className="h-3 w-px bg-border" />
          <div className="font-bold text-ink">
            Total: <span className="text-brand-600">{totalSeats}</span>
          </div>
        </div>
      </div>

      {/* SVG Preview Stage */}
      <div className="overflow-x-auto p-4 sm:p-6 bg-white flex justify-center">
        <svg
          viewBox={`0 0 ${VIEW_WIDTH} ${VIEW_HEIGHT}`}
          className="w-full max-w-4xl h-auto select-none"
          style={{ minWidth: '600px', maxHeight: '550px' }}
        >
          {/* Section Column Header Guides */}
          {sections.map((sec, i) => {
            const secSeats = seats.filter((s) => s.sectionId === sec.id);
            if (secSeats.length === 0) return null;

            const minX = Math.min(...secSeats.map((s) => s.x));
            const maxX = Math.max(...secSeats.map((s) => s.x));

            const leftPx = MARGIN_LEFT + minX * seatingWidth;
            const rightPx = MARGIN_LEFT + maxX * seatingWidth + SEAT_BOX_W;
            const centerPx = (leftPx + rightPx) / 2;

            return (
              <g key={sec.id}>
                <text
                  x={centerPx}
                  y={MARGIN_TOP - 16}
                  textAnchor="middle"
                  fontSize="11"
                  fontWeight="700"
                  fill="#64748B"
                  letterSpacing="0.05em"
                >
                  {sec.name.toUpperCase()} SECTION ({sec.totalSeats})
                </text>
                {/* Subtle section column outline */}
                <rect
                  x={leftPx - 6}
                  y={MARGIN_TOP - 6}
                  width={rightPx - leftPx + 12}
                  height={seatingHeight + SEAT_BOX_H + 12}
                  fill={i % 2 === 0 ? '#F8FAFC' : '#FFFFFF'}
                  stroke="#E2E8F0"
                  strokeWidth="0.8"
                  strokeDasharray="4 4"
                  rx="6"
                  opacity={0.6}
                />
              </g>
            );
          })}

          {/* Row Labels on Left and Right */}
          {rowsList.map(([label, rowSeats]) => {
            const avgY = rowSeats.reduce((acc, s) => acc + s.y, 0) / rowSeats.length;
            const yPx = MARGIN_TOP + avgY * seatingHeight;

            return (
              <g key={`row-label-${label}`}>
                {/* Left Row Pill */}
                <rect
                  x={MARGIN_LEFT - 32}
                  y={yPx}
                  width="22"
                  height="22"
                  rx="4"
                  fill="#F1F5F9"
                  stroke="#CBD5E1"
                  strokeWidth="1"
                />
                <text
                  x={MARGIN_LEFT - 21}
                  y={yPx + 15}
                  textAnchor="middle"
                  fontSize="10"
                  fontWeight="bold"
                  fill="#475569"
                >
                  {label}
                </text>

                {/* Right Row Pill */}
                <rect
                  x={VIEW_WIDTH - MARGIN_RIGHT + 10}
                  y={yPx}
                  width="22"
                  height="22"
                  rx="4"
                  fill="#F1F5F9"
                  stroke="#CBD5E1"
                  strokeWidth="1"
                />
                <text
                  x={VIEW_WIDTH - MARGIN_RIGHT + 21}
                  y={yPx + 15}
                  textAnchor="middle"
                  fontSize="10"
                  fontWeight="bold"
                  fill="#475569"
                >
                  {label}
                </text>
              </g>
            );
          })}

          {/* Seats Rendering */}
          {seats.map((seat) => {
            const xPx = MARGIN_LEFT + seat.x * seatingWidth;
            const yPx = MARGIN_TOP + seat.y * seatingHeight;
            const colors = TIER_COLORS[seat.type] || TIER_COLORS.REGULAR;
            const displayNumber = seat.seatNumber < 10 ? `0${seat.seatNumber}` : `${seat.seatNumber}`;

            return (
              <g key={`${seat.rowLabel}-${seat.seatNumber}`} className="cursor-pointer group">
                {/* Rounded Rectangle Seat Box */}
                <rect
                  x={xPx}
                  y={yPx}
                  width={SEAT_BOX_W}
                  height={SEAT_BOX_H}
                  rx="4"
                  fill={colors.bg}
                  stroke={colors.border}
                  strokeWidth="1.2"
                />
                {/* 2-Digit Seat Number */}
                <text
                  x={xPx + SEAT_BOX_W / 2}
                  y={yPx + 17}
                  textAnchor="middle"
                  fontSize="9.5"
                  fontWeight="bold"
                  fill={colors.text}
                >
                  {displayNumber}
                </text>
              </g>
            );
          })}

          {/* Screen Display at Bottom (Matching BookMyShow reference) */}
          <g transform={`translate(${VIEW_WIDTH / 2}, ${VIEW_HEIGHT - 38})`}>
            {/* Screen Trapezoid Bar */}
            <path
              d="M -180 0 L -150 14 L 150 14 L 180 0 Z"
              fill="#E0F2FE"
              stroke="#38BDF8"
              strokeWidth="1.5"
            />
            {/* Screen Caption */}
            <text
              x="0"
              y="26"
              textAnchor="middle"
              fontSize="10"
              fontWeight="700"
              fill="#64748B"
              letterSpacing="0.1em"
            >
              All eyes this way please
            </text>
          </g>
        </svg>
      </div>

      {/* Legend Footer */}
      <div className="flex flex-wrap items-center justify-between border-t border-border bg-surface-muted/30 px-5 py-2.5 text-xs text-ink-muted">
        <div className="flex flex-wrap items-center gap-4">
          <span className="font-semibold text-ink">Seat Tiers:</span>
          {(['REGULAR', 'PREMIUM', 'RECLINER', 'SOFA', 'WHEELCHAIR'] as SeatType[]).map((type) => (
            <div key={type} className="flex items-center gap-1.5">
              <span
                className="h-3 w-3 rounded-sm border"
                style={{
                  backgroundColor: TIER_COLORS[type].bg,
                  borderColor: TIER_COLORS[type].border,
                }}
              />
              <span>{SEAT_TYPE_LABELS[type]}</span>
            </div>
          ))}
        </div>

        <div className="text-[11px] text-ink-muted">
          Vertical and horizontal gaps represent real auditorium walking aisles.
        </div>
      </div>
    </div>
  );
};

