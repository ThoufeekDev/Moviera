import { useMutation, useQueryClient } from '@tanstack/react-query';
import { updateSeatLayout } from '../api/seats.api';
import type { UpdateSeatLayoutPayload } from '../types/seat.types';
import { theatreKeys } from '../keys';

export const useUpdateSeatLayout = (screenId: string) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (payload: UpdateSeatLayoutPayload) => updateSeatLayout(screenId, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: theatreKeys.seatLayout(screenId),
      });
    },
  });
};

