import { useCallback, useEffect, useRef, type RefObject } from 'react';
import type Konva from 'konva';
import { useSeatEditorStore } from '../stores/useSeatEditorStore';
import {
  clampDeltaToWorld,
  computeCornerBounds,
  cornerBoundsToBox,
  normalizedToWorld,
  snapToSeatGrid,
  worldToNormalized,
  type WorldRect,
} from '../utils/seatCoordinates';
import { DRAG_THRESHOLD_PX, SEAT_METRICS, ZOOM_LIMITS } from '../utils/seatMetrics';
import { SELECTION_THEME } from '../utils/seatTheme';

export const LAYOUT_BOX_PADDING = 24;

interface PendingSeatPress {
  kind: 'pending';
  seatId: string;
  startClientX: number;
  startClientY: number;
  modifier: boolean;
  wasInSelection: boolean;
}

interface SeatDrag {
  kind: 'drag';
  seatId: string;
  startClientX: number;
  startClientY: number;
  /** Start world position of every moved seat, captured once on drag start. */
  starts: Map<string, { x: number; y: number }>;
  anchor: { x: number; y: number };
  movedCorners: WorldRect;
  staticCorners: WorldRect | null;
  dx: number;
  dy: number;
}

interface MarqueeDrag {
  kind: 'marquee';
  startX: number;
  startY: number;
  currentX: number;
  currentY: number;
  append: boolean;
}

interface PanDrag {
  kind: 'pan';
  startClientX: number;
  startClientY: number;
  startX: number;
  startY: number;
}

type Interaction = PendingSeatPress | SeatDrag | MarqueeDrag | PanDrag;

export interface SeatCanvasInteractionOptions {
  stageRef: RefObject<Konva.Stage | null>;
  selectionBoxRef: RefObject<Konva.Rect | null>;
  boundsBoxRef: RefObject<Konva.Rect | null>;
  marqueeRef: RefObject<Konva.Rect | null>;
  snapToGrid: boolean;
  handToolActive: boolean;
}

const isTypingTarget = (target: EventTarget | null): boolean => {
  if (!(target instanceof HTMLElement)) return false;
  return (
    target.tagName === 'INPUT' ||
    target.tagName === 'TEXTAREA' ||
    target.tagName === 'SELECT' ||
    target.isContentEditable
  );
};

/**
 * Pointer interactions of the seat canvas:
 *  - press on a seat selects it immediately; moving 4px+ starts dragging the selection
 *  - drag moves Konva nodes imperatively (no React state per mousemove) and commits once
 *  - marquee starts only on empty canvas
 *  - pan with middle mouse, Space + drag, or the Hand tool
 */
export function useSeatCanvasInteractions({
  stageRef,
  selectionBoxRef,
  boundsBoxRef,
  marqueeRef,
  snapToGrid,
  handToolActive,
}: SeatCanvasInteractionOptions) {
  const nodesRef = useRef(new Map<string, Konva.Group>());
  const interactionRef = useRef<Interaction | null>(null);
  const spaceDownRef = useRef(false);
  const pointerOverRef = useRef(false);
  const optionsRef = useRef({ snapToGrid, handToolActive });

  const setCursor = useCallback(
    (cursor: string) => {
      const container = stageRef.current?.container();
      if (container) container.style.cursor = cursor;
    },
    [stageRef],
  );

  const isPanMode = useCallback(
    () => spaceDownRef.current || optionsRef.current.handToolActive,
    [],
  );

  useEffect(() => {
    optionsRef.current = { snapToGrid, handToolActive };
    if (!interactionRef.current) {
      setCursor(handToolActive || spaceDownRef.current ? 'grab' : 'default');
    }
  }, [snapToGrid, handToolActive, setCursor]);

  const registerNode = useCallback((id: string, node: Konva.Group | null) => {
    if (node) {
      nodesRef.current.set(id, node);
    } else {
      nodesRef.current.delete(id);
    }
  }, []);

  const clientToWorld = useCallback(
    (clientX: number, clientY: number) => {
      const stage = stageRef.current;
      if (!stage) return null;
      const rect = stage.container().getBoundingClientRect();
      const scale = stage.scaleX() || 1;
      return {
        x: (clientX - rect.left - stage.x()) / scale,
        y: (clientY - rect.top - stage.y()) / scale,
      };
    },
    [stageRef],
  );

  /** Re-applies selection box and layout box from the committed store state. */
  const syncOverlaysFromStore = useCallback(() => {
    const { seats, selectedSeatIds } = useSeatEditorStore.getState();
    const all = computeCornerBounds(seats.map((s) => normalizedToWorld(s.x, s.y)));
    const selected = computeCornerBounds(
      seats.filter((s) => selectedSeatIds.has(s.id)).map((s) => normalizedToWorld(s.x, s.y)),
    );

    if (all) boundsBoxRef.current?.setAttrs(cornerBoundsToBox(all, LAYOUT_BOX_PADDING));
    if (selected) {
      selectionBoxRef.current?.setAttrs({
        ...cornerBoundsToBox(selected, SELECTION_THEME.selectionBox.padding),
        visible: true,
      });
    } else {
      selectionBoxRef.current?.visible(false);
    }
    stageRef.current?.batchDraw();
  }, [boundsBoxRef, selectionBoxRef, stageRef]);

  const beginSeatDrag = useCallback((pending: PendingSeatPress): SeatDrag | null => {
    const store = useSeatEditorStore.getState();
    const moveIds = store.selectedSeatIds.has(pending.seatId)
      ? new Set(store.selectedSeatIds)
      : new Set([pending.seatId]);
    if (!store.selectedSeatIds.has(pending.seatId)) {
      store.selectSeat(pending.seatId, false);
    }

    const starts = new Map<string, { x: number; y: number }>();
    const staticPoints: Array<{ x: number; y: number }> = [];
    for (const seat of store.seats) {
      const point = normalizedToWorld(seat.x, seat.y);
      if (moveIds.has(seat.id)) {
        starts.set(seat.id, point);
      } else {
        staticPoints.push(point);
      }
    }

    const anchor = starts.get(pending.seatId);
    const movedCorners = computeCornerBounds(Array.from(starts.values()));
    if (!anchor || !movedCorners) return null;

    return {
      kind: 'drag',
      seatId: pending.seatId,
      startClientX: pending.startClientX,
      startClientY: pending.startClientY,
      starts,
      anchor,
      movedCorners,
      staticCorners: computeCornerBounds(staticPoints),
      dx: 0,
      dy: 0,
    };
  }, []);

  const updateSeatDrag = useCallback(
    (drag: SeatDrag, event: MouseEvent) => {
      const stage = stageRef.current;
      if (!stage) return;
      const scale = stage.scaleX() || 1;

      const rawDx = (event.clientX - drag.startClientX) / scale;
      const rawDy = (event.clientY - drag.startClientY) / scale;

      let dx = rawDx;
      let dy = rawDy;
      if (optionsRef.current.snapToGrid && !event.altKey) {
        const snapped = snapToSeatGrid(drag.anchor.x + rawDx, drag.anchor.y + rawDy);
        dx = snapped.x - drag.anchor.x;
        dy = snapped.y - drag.anchor.y;
      }

      const clamped = clampDeltaToWorld(drag.movedCorners, dx, dy);
      drag.dx = clamped.dx;
      drag.dy = clamped.dy;

      for (const [id, start] of drag.starts) {
        nodesRef.current.get(id)?.position({ x: start.x + drag.dx, y: start.y + drag.dy });
      }

      const moved: WorldRect = {
        minX: drag.movedCorners.minX + drag.dx,
        maxX: drag.movedCorners.maxX + drag.dx,
        minY: drag.movedCorners.minY + drag.dy,
        maxY: drag.movedCorners.maxY + drag.dy,
      };
      const all: WorldRect = drag.staticCorners
        ? {
            minX: Math.min(moved.minX, drag.staticCorners.minX),
            maxX: Math.max(moved.maxX, drag.staticCorners.maxX),
            minY: Math.min(moved.minY, drag.staticCorners.minY),
            maxY: Math.max(moved.maxY, drag.staticCorners.maxY),
          }
        : moved;

      selectionBoxRef.current?.setAttrs({
        ...cornerBoundsToBox(moved, SELECTION_THEME.selectionBox.padding),
        visible: true,
      });
      boundsBoxRef.current?.setAttrs(cornerBoundsToBox(all, LAYOUT_BOX_PADDING));
      stage.batchDraw();
    },
    [boundsBoxRef, selectionBoxRef, stageRef],
  );

  const cancelInteraction = useCallback(() => {
    const interaction = interactionRef.current;
    interactionRef.current = null;
    if (!interaction) return;

    if (interaction.kind === 'drag') {
      for (const [id, start] of interaction.starts) {
        nodesRef.current.get(id)?.position({ x: start.x, y: start.y });
      }
      syncOverlaysFromStore();
    } else if (interaction.kind === 'marquee') {
      marqueeRef.current?.visible(false);
      stageRef.current?.batchDraw();
    } else if (interaction.kind === 'pan') {
      const { pan } = useSeatEditorStore.getState();
      stageRef.current?.position(pan);
      stageRef.current?.batchDraw();
    }
    setCursor(isPanMode() ? 'grab' : 'default');
  }, [isPanMode, marqueeRef, setCursor, stageRef, syncOverlaysFromStore]);

  // Window-level listeners so a drag keeps working when the pointer leaves the canvas
  useEffect(() => {
    const onMouseMove = (event: MouseEvent) => {
      let interaction = interactionRef.current;
      if (!interaction) return;

      if (interaction.kind === 'pending') {
        const travelled = Math.hypot(
          event.clientX - interaction.startClientX,
          event.clientY - interaction.startClientY,
        );
        if (travelled < DRAG_THRESHOLD_PX) return;

        const drag = beginSeatDrag(interaction);
        if (!drag) {
          interactionRef.current = null;
          return;
        }
        interactionRef.current = drag;
        interaction = drag;
        setCursor('grabbing');
      }

      if (interaction.kind === 'drag') {
        updateSeatDrag(interaction, event);
      } else if (interaction.kind === 'marquee') {
        const world = clientToWorld(event.clientX, event.clientY);
        if (!world) return;
        interaction.currentX = world.x;
        interaction.currentY = world.y;
        marqueeRef.current?.setAttrs({
          x: Math.min(interaction.startX, world.x),
          y: Math.min(interaction.startY, world.y),
          width: Math.abs(world.x - interaction.startX),
          height: Math.abs(world.y - interaction.startY),
          visible: true,
        });
        stageRef.current?.batchDraw();
      } else if (interaction.kind === 'pan') {
        stageRef.current?.position({
          x: interaction.startX + (event.clientX - interaction.startClientX),
          y: interaction.startY + (event.clientY - interaction.startClientY),
        });
        stageRef.current?.batchDraw();
      }
    };

    const onMouseUp = () => {
      const interaction = interactionRef.current;
      interactionRef.current = null;
      if (!interaction) return;

      const store = useSeatEditorStore.getState();

      if (interaction.kind === 'pending') {
        // Plain click on a seat that was part of a multi-selection collapses it to that seat
        if (!interaction.modifier && interaction.wasInSelection && store.selectedSeatIds.size > 1) {
          store.selectSeat(interaction.seatId, false);
        }
      } else if (interaction.kind === 'drag') {
        setCursor(isPanMode() ? 'grab' : 'default');
        if (interaction.dx !== 0 || interaction.dy !== 0) {
          const updates = Array.from(interaction.starts, ([id, start]) => {
            const normalized = worldToNormalized(start.x + interaction.dx, start.y + interaction.dy);
            return { id, x: normalized.x, y: normalized.y };
          });
          // One call = one undo/redo history entry; the dirty flag is derived from the store
          store.batchUpdatePositions(updates);
        }
      } else if (interaction.kind === 'marquee') {
        marqueeRef.current?.visible(false);
        stageRef.current?.batchDraw();

        const x1 = Math.min(interaction.startX, interaction.currentX);
        const x2 = Math.max(interaction.startX, interaction.currentX);
        const y1 = Math.min(interaction.startY, interaction.currentY);
        const y2 = Math.max(interaction.startY, interaction.currentY);

        if (x2 - x1 > 3 || y2 - y1 > 3) {
          const enclosed: string[] = [];
          for (const seat of store.seats) {
            const p = normalizedToWorld(seat.x, seat.y);
            if (
              p.x + SEAT_METRICS.width >= x1 &&
              p.x <= x2 &&
              p.y + SEAT_METRICS.height >= y1 &&
              p.y <= y2
            ) {
              enclosed.push(seat.id);
            }
          }
          store.selectMultiple(enclosed, interaction.append);
        }
      } else if (interaction.kind === 'pan') {
        const stage = stageRef.current;
        if (stage) store.setPan({ x: stage.x(), y: stage.y() });
        setCursor(isPanMode() ? 'grab' : 'default');
      }
    };

    const onKeyDown = (event: KeyboardEvent) => {
      if (isTypingTarget(event.target)) return;

      if (event.code === 'Space') {
        if (pointerOverRef.current) event.preventDefault();
        if (!spaceDownRef.current) {
          spaceDownRef.current = true;
          if (!interactionRef.current) setCursor('grab');
        }
      } else if (event.key === 'Escape' && interactionRef.current) {
        cancelInteraction();
      }
    };

    const onKeyUp = (event: KeyboardEvent) => {
      if (event.code === 'Space') {
        spaceDownRef.current = false;
        if (!interactionRef.current) setCursor(optionsRef.current.handToolActive ? 'grab' : 'default');
      }
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', cancelInteraction);
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', cancelInteraction);
    };
  }, [
    beginSeatDrag,
    cancelInteraction,
    clientToWorld,
    isPanMode,
    marqueeRef,
    setCursor,
    stageRef,
    updateSeatDrag,
  ]);

  /** Mouse press on a seat: select immediately, then wait for the drag threshold. */
  const handleSeatMouseDown = useCallback(
    (id: string, e: Konva.KonvaEventObject<MouseEvent>) => {
      if (e.evt.button !== 0 || isPanMode()) return; // middle mouse / pan mode pan the stage
      e.cancelBubble = true;
      e.evt.preventDefault();

      const store = useSeatEditorStore.getState();
      const modifier = e.evt.shiftKey || e.evt.ctrlKey || e.evt.metaKey;
      const wasInSelection = store.selectedSeatIds.has(id);

      if (modifier) {
        store.selectSeat(id, true);
        if (wasInSelection) {
          interactionRef.current = null; // toggled off: nothing to drag
          return;
        }
      } else if (!wasInSelection) {
        store.selectSeat(id, false);
      }

      interactionRef.current = {
        kind: 'pending',
        seatId: id,
        startClientX: e.evt.clientX,
        startClientY: e.evt.clientY,
        modifier,
        wasInSelection,
      };
    },
    [isPanMode],
  );

  /** Mouse press on the stage: pan, or start a marquee when pressing on empty canvas. */
  const handleStageMouseDown = useCallback(
    (e: Konva.KonvaEventObject<MouseEvent>) => {
      const stage = stageRef.current;
      if (!stage) return;
      const evt = e.evt;

      if (evt.button === 1 || (evt.button === 0 && isPanMode())) {
        evt.preventDefault();
        interactionRef.current = {
          kind: 'pan',
          startClientX: evt.clientX,
          startClientY: evt.clientY,
          startX: stage.x(),
          startY: stage.y(),
        };
        setCursor('grabbing');
        return;
      }

      if (evt.button !== 0) return;
      if (e.target !== stage && e.target.name() !== 'background') return;

      const append = evt.shiftKey || evt.ctrlKey || evt.metaKey;
      if (!append) useSeatEditorStore.getState().clearSelection();

      const world = clientToWorld(evt.clientX, evt.clientY);
      if (!world) return;
      interactionRef.current = {
        kind: 'marquee',
        startX: world.x,
        startY: world.y,
        currentX: world.x,
        currentY: world.y,
        append,
      };
    },
    [clientToWorld, isPanMode, setCursor, stageRef],
  );

  /** Cursor feedback while idle. */
  const handleStageMouseMove = useCallback(
    (e: Konva.KonvaEventObject<MouseEvent>) => {
      pointerOverRef.current = true;
      if (interactionRef.current) return;
      if (isPanMode()) {
        setCursor('grab');
        return;
      }
      setCursor(e.target.findAncestor('.seat') ? 'move' : 'default');
    },
    [isPanMode, setCursor],
  );

  const handleStageMouseLeave = useCallback(() => {
    pointerOverRef.current = false;
  }, []);

  const handleWheel = useCallback(
    (e: Konva.KonvaEventObject<WheelEvent>) => {
      e.evt.preventDefault();
      const stage = stageRef.current;
      const pointer = stage?.getPointerPosition();
      if (!stage || !pointer) return;

      const store = useSeatEditorStore.getState();
      const oldScale = store.zoom;
      const scaleBy = 1.08;
      const nextScale = e.evt.deltaY < 0 ? oldScale * scaleBy : oldScale / scaleBy;
      const clampedScale = Math.max(ZOOM_LIMITS.min, Math.min(ZOOM_LIMITS.max, nextScale));

      const pointTo = {
        x: (pointer.x - store.pan.x) / oldScale,
        y: (pointer.y - store.pan.y) / oldScale,
      };

      store.setZoom(clampedScale);
      store.setPan({
        x: pointer.x - pointTo.x * clampedScale,
        y: pointer.y - pointTo.y * clampedScale,
      });
    },
    [stageRef],
  );

  return {
    registerNode,
    handleSeatMouseDown,
    handleStageMouseDown,
    handleStageMouseMove,
    handleStageMouseLeave,
    handleWheel,
  };
}

