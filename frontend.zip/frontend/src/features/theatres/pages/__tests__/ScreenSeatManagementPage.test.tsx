import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AxiosError, AxiosHeaders } from 'axios';
import ScreenSeatManagementPage from '../ScreenSeatManagementPage';
import * as seatsApi from '../../api/seats.api';
import * as screensApi from '../../api/screens.api';
import * as theatreOverviewApi from '../../api/getTheatreOverview.api';

describe('ScreenSeatManagementPage Integration', () => {
  let queryClient: QueryClient;

  const mockOverview = {
    theatre: {
      id: 'th-1',
      name: 'Grand Cineplex',
      city: 'Metropolis',
      status: 'ACTIVE' as const,
      totalScreens: 2,
    },
    screens: [],
    shows: [],
    analytics: { totalBookings: 0, totalRevenuePaise: 0 },
  };

  const mockScreens = {
    items: [
      {
        id: 'sc-1',
        theatreId: 'th-1',
        name: 'Screen 1 IMAX',
        slug: 'screen-1-imax',
        isActive: true,
        totalSeats: 2,
        totalRows: 1,
        totalShows: 3,
        seatConfigurationStatus: 'CONFIGURED' as const,
      },
    ],
    pagination: { page: 1, limit: 10, total: 1, totalPages: 1 },
  };

  const mockSeats = [
    {
      id: 's-1',
      screenId: 'sc-1',
      rowLabel: 'A',
      seatNumber: 1,
      label: 'A1',
      x: 0.2,
      y: 0.3,
      rotation: 0,
      type: 'REGULAR' as const,
      isActive: true,
    },
    {
      id: 's-2',
      screenId: 'sc-1',
      rowLabel: 'A',
      seatNumber: 2,
      label: 'A2',
      x: 0.4,
      y: 0.3,
      rotation: 0,
      type: 'PREMIUM' as const,
      isActive: true,
    },
  ];

  beforeEach(() => {
    queryClient = new QueryClient({
      defaultOptions: {
        mutations: { retry: false },
        queries: { retry: false },
      },
    });
    vi.clearAllMocks();

    vi.spyOn(theatreOverviewApi, 'getOverview').mockResolvedValue(mockOverview as any);
    vi.spyOn(screensApi, 'getScreens').mockResolvedValue(mockScreens as any);
  });

  const renderPage = (initialUrl = '/theatre-admin/theatres/th-1/screens/sc-1/seats') =>
    render(
      <QueryClientProvider client={queryClient}>
        <MemoryRouter initialEntries={[initialUrl]}>
          <Routes>
            <Route
              path="/theatre-admin/theatres/:theatreId/screens/:screenId/seats"
              element={<ScreenSeatManagementPage />}
            />
          </Routes>
        </MemoryRouter>
      </QueryClientProvider>,
    );

  it('renders setup mode when screen has no seats configured', async () => {
    vi.spyOn(seatsApi, 'getScreenSeatLayout').mockResolvedValue([]);

    renderPage();

    await waitFor(() => {
      expect(screen.getByText('Configure Seating Layout')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /generate seat grid/i })).toBeInTheDocument();
    });
  });

  it('renders editor mode and toolbar when seats exist', async () => {
    vi.spyOn(seatsApi, 'getScreenSeatLayout').mockResolvedValue(mockSeats);

    renderPage();

    await waitFor(() => {
      expect(
        screen.getByText(/Screen 1 IMAX — Seating Layout Editor/i),
      ).toBeInTheDocument();
      expect(screen.getByText(/2 Total Seats/i)).toBeInTheDocument();
    });
  });

  it('switches to table view and displays accessible list of seats', async () => {
    vi.spyOn(seatsApi, 'getScreenSeatLayout').mockResolvedValue(mockSeats);

    const user = userEvent.setup();
    renderPage();

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /table list/i })).toBeInTheDocument();
    });

    const tableModeBtn = screen.getByRole('button', { name: /table list/i });
    await user.click(tableModeBtn);

    await waitFor(() => {
      expect(screen.getByRole('table')).toBeInTheDocument();
      expect(screen.getByText('A1')).toBeInTheDocument();
      expect(screen.getByText('A2')).toBeInTheDocument();
    });
  });

  it('handles save layout errors with descriptive banner', async () => {
    vi.spyOn(seatsApi, 'getScreenSeatLayout').mockResolvedValue(mockSeats);

    const axiosError = new AxiosError('Conflict');
    axiosError.response = {
      status: 409,
      statusText: 'Conflict',
      headers: {},
      config: { headers: new AxiosHeaders() },
      data: {
        success: false,
        code: 'CONFLICT',
        message: 'Screen is inactive',
      },
    };
    vi.spyOn(seatsApi, 'updateSeatProperties').mockRejectedValue(axiosError);

    const user = userEvent.setup();
    renderPage();

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /table list/i })).toBeInTheDocument();
    });

    // Switch to table view to modify property
    const tableModeBtn = screen.getByRole('button', { name: /table list/i });
    await user.click(tableModeBtn);

    // Toggle active status for A1
    const activeBtns = screen.getAllByRole('button', { name: /active/i });
    await user.click(activeBtns[0]);

    // Now save layout
    const saveBtn = screen.getByRole('button', { name: /save layout/i });
    await user.click(saveBtn);

    await waitFor(() => {
      expect(screen.getByText(/Screen is inactive/i)).toBeInTheDocument();
    });
  });
});
