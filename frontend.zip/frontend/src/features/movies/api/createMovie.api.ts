import api from "@/shared/lib/axios";
import type { CreateMovieFormData } from "../schemas/createMovie.schema";


export const createMovie = async (
    data: CreateMovieFormData
) => {
    const formData = new FormData();

    formData.append('title', data.title);
    formData.append('description', data.description);
    formData.append('duration', String(data.duration));

    formData.append(
        'releaseDate',
        new Date(data.releaseDate).toISOString(),
    );

    formData.append('primaryGenreId', data.primaryGenreId);
    formData.append(
  'genreIds',
  JSON.stringify(data.genreIds)
);
    formData.append('certification', data.certificate);

    formData.append(
        'languages',
        JSON.stringify(data.languages)
    );

    formData.append(
  'theatreFormatIds',
  JSON.stringify(data.theatreFormatIds)
);

    formData.append(
        'cast',
        JSON.stringify(data.cast)
    );

    formData.append(
        'crew',
        JSON.stringify(data.crew)
    );

    formData.append('poster', data.poster);
    formData.append('backdrop', data.backdrop);

    if (data.trailerUrl) {
        formData.append(
            'trailerUrl',
            data.trailerUrl
        );
    }

    const response = await api.post('/movies', formData);
    return response.data;
    
}